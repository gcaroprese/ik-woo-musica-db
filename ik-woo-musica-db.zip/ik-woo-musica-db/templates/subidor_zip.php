<?php
/*
Template: Subir canciones en masa IK Woo Musica Ajax
Author: Gabriel Caroprese / Inforket.com
Update Date: 14/03/2021
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

//Cargo el CSS y Scripts
ik_woomusicadb_backend_script_css();

?>
<div id="ik_musicadb_css_subidor_masa">
    <h1>Subir discos de forma masiva</h1>
    <div class="ik_musicadb_css_subir_canciones subidor_zip_wrapper">
        <span id="ik_musicadb_album_zip_mensaje">Los archivos soportados dentro del zip son unicamente JPG y MP3.</span>
        <input type="file" multiple id="ik_musicadb_album_zip_files" />
        <input type="button" id="ik_musicadb_album_zip_files_btn" class="button-primary botones_subir_zip" value="Seleccionar Archivos Zip" onclick="document.getElementById('ik_musicadb_album_zip_files').click();" />
        <input type="button" id="ik_musicadb_album_zip_subir_files_btn" disabled class="button-primary botones_subir_zip" value="Subir Archivos Zip" />
    </div>
    <div id="ik_musicadb_css_procesamiento_zip">
        <p></p>
    </div>
    <button id="ik_musicadb_album_zip_resetear_subir_btn" class="button">Cancelar</button>
</div>