<?php
/*

Template: Woocommerce musicdb - Panel
Author: Gabriel Caroprese / Inforket.com
Update Date: 18/07/2021
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

//Cargo el CSS y Scripts
ik_woomusicadb_backend_script_css();

//Defino la variable de resultado para cuando se guarde algo
$resultado = ' ';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['fotoalbumdefecto']) && isset($_POST['demominutos']) && isset($_POST['preciopista']) && isset($_POST['genero']) ){

    // Levanto las variables que submití en el form

    $fotoalbumdefecto = sanitize_text_field($_POST['fotoalbumdefecto']);
    $demominutos = sanitize_text_field($_POST['demominutos']);
    $preciopista = floatval($_POST['preciopista']);
    $genero = sanitize_text_field($_POST['genero']);
    
    /* 
        Chequea si el sistema ya fue cargado con los datos de acceso 
        a la base de dato y URL de la web musicdb 
        para ver si hago un INSERT o un UPDATE en la base de datos
    */
    
    if (isset($_POST['modo_privado'])){
        $privado = true;
    } else {
        $privado = false;
    }
    
    $config_woomusicdb  = array (
            'fotoalbumdefecto' =>$fotoalbumdefecto,
            'demominutos' =>$demominutos,
            'preciopista' =>$preciopista,
            'genero' =>$genero,
            'privado' => $privado,
    );       
                    
    update_option('ik_musicadb_info', $config_woomusicdb);
    $resultado = '<span class="dashicons dashicons-yes-alt"></span> Guardado';
    
    if (isset($_POST['recapkey']) && isset($_POST['recapseckey'])){
        $recaptcha_k = sanitize_text_field($_POST['recapkey']);
        $recaptcha_s = sanitize_text_field($_POST['recapseckey']);
    
        if (isset($_POST['userecaptcha'])){
            $checkbox_recaptcha = "1";
        } else {
            $checkbox_recaptcha = "0";
        }
        
        update_option('ik_woomusicadb_recaptcha_k', $recaptcha_k);
        update_option('ik_woomusicadb_recaptcha_s', $recaptcha_s);
        update_option('ik_woomusicadb_recaptcha_use', $checkbox_recaptcha);        
    }

    if (isset($_POST['url_search'])){
        if (strlen($_POST['url_search']) < 128){
            $url_search = sanitize_url($_POST['url_search']);
    
            update_option('ik_woomusicadb_url_search', $url_search);    
        }
    } else {
        delete_option('ik_woomusicadb_url_search');        
    }
    
}
?>
<div id="panel_form_woomusicdb">
    <div class="ik_woomusicdb_panel">
    <h1>Configuración - Woocommerce Musica DB</h1>
    <form action="" method="post" id="db-woomusicdb-form" enctype="multipart/form-data" autocomplete="no">
        <?php 
            // Variables si existen. Sino va a dar un valor vacío.
            $fotoalbumdefecto = ik_woomusicdb_datainfo('fotoalbumdefecto');
            $demominutos = ik_woomusicdb_datainfo('demominutos');
            $preciopista = ik_woomusicdb_datainfo('preciopista');
            $genero = ik_woomusicdb_datainfo('genero');
            $privado = ik_woomusicdb_datainfo('privado');
            $recaptchakey = get_option('ik_woomusicadb_recaptcha_k');
            $recaptchasecret = get_option('ik_woomusicadb_recaptcha_s');
            $recapchacheckData = get_option('ik_woomusicadb_recaptcha_use');
            $url_search = get_option('ik_woomusicadb_url_search');

            if ($privado == true){
                $privado_check = 'checked';
            } else {
                $privado_check = '';
            }
            if ($recaptchakey == false || $recaptchakey == NULL){
                $recaptchakey = '';
            }
            if ($recaptchasecret == false || $recaptchasecret == NULL){
                $recaptchasecret = '';
            }
            if ($recapchacheckData != false && $recapchacheckData != '0' && $recapchacheckData != NULL){
                $recapchacheck = 'checked';
            } else {
                $recapchacheck = '';
            }
        ?>
        <label for="upload_image">
            <h3>Foto de &Aacute;lbum por Defecto</h3>
            <img id="ik_musicdb_album_img_src" src="<?php echo $fotoalbumdefecto ; ?>" />
            <input type="hidden" name="fotoalbumdefecto" id="ik_musicdb_album_img" value="<?php echo $fotoalbumdefecto ; ?>" />
            <input type="hidden" name="ik_musicdb_album_image_id" id="ik_musicdb_album_image_id" value="" />
            <input type='button' class="button-primary" value="<?php esc_attr_e( 'Cambiar Imagen' ); ?>" id="ik_musicdb_cambiar_album_defecto" />
        </label>
        <label>
            <h3>Duraci&oacute;n de la Demo (Segundos)</h3>
            <input required type="number" name="demominutos" value="<?php echo $demominutos; ?>" placeholder="Ingresar Segundos" autocomplete="off" />
        </label>        
        <label>
            <h3>Precio por Pista</h3>
            <input required type="number" name="preciopista" step="0.01" min="0" value="<?php echo $preciopista; ?>" placeholder="Ingresar Valor" autocomplete="off" />
        </label>  
        <label>
            <h3>Nombre de G&eacute;nero por defecto</h3>
            <input required type="text" name="genero" value="<?php echo $genero; ?>" placeholder="Ingresar nombre del g&eacute;nero" autocomplete="off" />
        </label>  
        <label>
            <h3>Modo privado<br />(s&oacute;lo usuarios logueados)</h3>
            <input type="checkbox" name="modo_privado" <?php echo $privado_check; ?> value="1" /> Habilitar modo privado
        </label>  
        <hr>
        <h2>Invisible Recaptcha (Evadir robots)</h2>
        <label for="recaptcha-key">
            <span>Crear keys en <a href="https://www.google.com/recaptcha/admin" target="_blank">Google Recaptcha</a></span>
            <h3>API Key</h3>
            <input type="text" name="recapkey" value="<?php echo $recaptchakey; ?>" />
        </label>
        <label for="recaptcha-secret-key">
            <h3>Secret Key</h3>
            <input type="text" name="recapseckey" value="<?php echo $recaptchasecret; ?>" />
        </label>
        <label>
            <input type="checkbox" name="userecaptcha" <?php echo $recapchacheck; ?> value="1"> Habilitar Recaptcha.
        </label>
        <hr>
        <h2>Buscador</h2>
        <label for="contacto_shortcode">
            <span>Poner URL de búsqueda de canciones para enlazar albums</span>
            <small>Ejemplo: https://web.com/buscar/</small>
            <input type="url" name="url_search" placeholder="Ejemplo: https://web.com/buscar/" value="<?php echo esc_url($url_search); ?>" />
        </label>        
    	<input type="submit" value="Guardar">
    	<div id="ik_musicdb_resultado" style="display: none"><?php echo $resultado; ?></div>
    </form>
</div>