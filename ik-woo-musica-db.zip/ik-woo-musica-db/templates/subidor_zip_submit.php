<?php
/*
Template: Subir canciones en masa IK Woo Musica submit
Author: Gabriel Caroprese / Inforket.com
Update Date: 14/03/2021
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
$mensaje = '';
$mostrarmensaje = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $mostrarmensaje = 'style="display:block;"';
    $data_submit = ik_woomusicadb_subir_zip_album();
    if(is_array($data_submit)){
        if(isset($data_submit['mensaje'])){
            $mensaje = $data_submit['mensaje'];;
        } else {
            $zip_name = $data_submit['name'];
            $file_name = $data_submit['file_name'];
            $album_dir = $data_submit['fileroot'];
            $resultado = ik_woomusicadb_crear_album_zip($file_name,$album_dir,$zip_name);
            if(isset($resultado['mensaje'])){
                $mensaje = $resultado['mensaje'];
            } else {
                $mensaje = 'Error creando album.';
            }
        }
    } else {
        $mensaje = 'Error';     
    }
}
?>
<div id="ik_musicadb_css_subidor_masa">
    <h1>Subir discos de forma masiva</h1>        
    <form class="ik_musicadb_css_subir_canciones subidor_zip_wrapper" enctype="multipart/form-data" action="" method="post">
        <span id="ik_musicadb_album_zip_mensaje">Los archivos soportados dentro del zip son unicamente JPG y MP3.</span>
        <input type="file" name="file" class="button-primary botones_subir_zip">
        <input type="submit" class="button-primary botones_subir_zip" value="Subir Archivos Zip" />
    </form>
    <div id="ik_musicadb_css_procesamiento_zip" <?php echo $mostrarmensaje; ?>>
        <p><?php echo $mensaje; ?></p>
    </div>
</div>