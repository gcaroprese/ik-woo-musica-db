<?php
/*
Template: Admin Canciones IK Woo Musica
Author: Gabriel Caroprese / Inforket.com
Update Date: 15/07/2021
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

//Cargo el subidor de media
wp_enqueue_media();

$cantlistando = 30;

$url_actual = get_site_url().'/wp-admin/admin.php?page=ik_woomusicadb_canciones';

// Si se busca algo
$keyword = '';
$busqueda = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    if (isset($_POST['keyword_album'])){
        $keyword = sanitize_text_field($_POST['keyword_album']);
        $busqueda = true;
    }
}
?>
<div id="ik_musicadb_css_canciones">
    <h1>Subir Canciones</h1>
    <div class="ik_musicadb_css_subir_canciones">
        <div id="ik_musicadb_album_input">
            <span id="ik_musicadb_album_mensaje">Crear uno nuevo o escribir y seleccionar uno ya existente.</span>
            <input type="hidden" value="0" id="ik_musicadb_album_id" name="ik_musicadb_album_id" />
            <input type="hidden" value="0" id="ik_musicadb_music_id" name="ik_musicadb_music_id" />
            <input type="text" placeholder="Nombre del Album" value="" id="ik_musicadb_album_nombre" />
        </div>
        <input type="button" class="button-primary" value="Subir" id="ik_musicadb_subir_canciones" />
    </div>
    <div id="ik_musicadb_album_reproductor" cancion_id="0"></div>
    <div id="ik_musicadb_album_popup_detalles" class="ik_music_db_popup" album_id="0" style="display:none">
        <div class="ik_musicdb_btn_cerrar_popup">
            <span class="dashicons dashicons-dismiss"></span>
        </div>
        <div class="ik_musicadb_album_popup_content"></div>
        <div class="ik_musicadb_editar_cancion_popup"></div>
    </div>
    <div id="ik_musicadb_css_albums_contenido">
        <div class="ik_musicadb_css_album_subidos">
            <div class="ik_musicadb_panel_buscar">
                <div class="icono_busqueda">
                    <span class="dashicons dashicons-search"></span>
                </div>
                <div class="ik_musicadb_panel_buscador_albums">
                    <form action="" method="post">
                    <input type="text" name="keyword_album" placeholder="Canciones, &aacute;lbums, int&eacute;rpretes..." value="<?php echo $keyword; ?>">
                    <input type="submit" value="Buscar" class="button">
                </div>
            </div>
            <div class="ik_musicadb_albums_container">
        <?php
    // I search translators matching the terms
    $albumsData = new Ik_MusicaDB_Albums();
    
    if ($busqueda == false){
        $albumsEncontrados = $albumsData->get_albums($cantlistando);
    } else {
        
        $albumsEncontrados = $albumsData->get_albums($cantlistando, 'id', 'DESC', $keyword);
    }

    if ($albumsEncontrados != false){
        $albums = $albumsEncontrados->listado;
        $total = $albumsEncontrados->total;
    } else {
        $albums = false;
        $total = 0;
    }
    
    // I assign values for comments from admin and translator
    if ($albums !== false){
        $albums_listado = '';
        foreach ( $albums as $album ) {
			
			$album_foto = ik_woomusicadb_get_imagenes_album($album->id_imgs);
			
			//ver si album es favorito
			$valor_favorito = absint($album->fav);
			if ($valor_favorito === 0){
			    $favoritoEstrella = '<span class="dashicons dashicons-star-empty"></span>';
			} else {
			    $favoritoEstrella = '<span class="dashicons dashicons-star-filled"></span>';
			}
			  
            $albums_listado .= '
            <div class="ik_woomusicadb_album_medio_box">
                <div class="ik_woomusicadb_agregar_fav" fav="'.$valor_favorito.'">
                   '.$favoritoEstrella.'
                </div>
                <div class="ik_woomusicadb_album_medio" album_id="'.$album->id.'">
                    <div class="ik_woomusicadb_album_medio_portada">
                        '.$album_foto.'
                    </div>
                    <div class="ik_woomusicadb_album_medio_datos">
                        <div class="ik_musicadb_id_album">
                            <span>ID de &Aacute;lbum: </span>
                            <span>#'.$album->id.'</span>
                        </div>
                        <div class="ik_musicadb_titulo_album">
                            <span>T&iacute;tulo: </span>
                            <span>'.$album->nombre.'</span>
                        </div>
                        <div class="ik_musicadb_interpretes_album">
                            <span>Int&eacute;rpretes: </span>
                            <span>'.$album->interpretes.'</span>
                        </div>
                        <div class="ik_musicadb_year_album">
                            <span>A&ntilde;o: </span>
                            <span>'.$album->year.'</span>
                        </div>
                        <div class="ik_musicadb_genero_album">
                            <span>G&eacute;nero: </span>
                            <span>'.$album->genero.'</span>
                        </div>
                    </div>
                </div>
            </div>';
        }
        echo $albums_listado;
        echo ik_woomusicadb_get_paginado($url_actual, $total, $cantlistando);
        
    } else {
        if ($busqueda == true){
        ?>
        <p class="ik_musicadb_nada_encontrado">No se encontraron resultados asociados a tu t&eacute;rmino de b&uacute;squeda.</p>
        <?php
        }
    }
        
    ?>
     <div>Total Albums: <?php echo $total; ?></div>
            </div>
        </div>
    </div>
</div>