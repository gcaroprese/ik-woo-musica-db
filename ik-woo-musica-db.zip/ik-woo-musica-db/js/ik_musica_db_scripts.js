jQuery(document).ready( function($) {
    function htmlDecode(input){
      var e = document.createElement('textarea');
      e.innerHTML = input;
      return e.childNodes.length === 0 ? "" : e.childNodes[0].nodeValue;
    }

    function ik_process_waitTime(ms) {
        var start = Date.now(),
            now = start;
        while (now - start < ms) {
          now = Date.now();
        }
    }

    function calculateWaitTime(fileSize) {
        const KB = 1024;
        const MB = 1024 * KB;
        const waitTimePerMB = 500;
    
        if (fileSize < MB) {
            return waitTimePerMB;
        } else {
            return Math.ceil(fileSize / MB) * waitTimePerMB;
        }
    }

    jQuery('input#ik_musicdb_cambiar_album_defecto').click(function(e) {
        e.preventDefault();
        var image_frame;
        if(image_frame){
            image_frame.open();
        }
        // Define image_frame as wp.media object
        image_frame = wp.media({
            title: 'Subir Imagen Por Defecto',
            multiple : false,
            library : {
                type : 'image',
            }
       });

       image_frame.on('close',function() {
            // On close, get selections and save to the hidden input
            // plus other AJAX stuff to refresh the image preview
            var selection =  image_frame.state().get('selection');
            var gallery_ids = new Array();
            var my_index = 0;
            selection.each(function(attachment) {
                gallery_ids[my_index] = attachment['id'];
                my_index++;
            });
            
            var ids = gallery_ids.join(",");
            jQuery('input#ik_musicdb_album_image_id').val(ids);
            ik_musicdb_refresh_image(ids);
        });

        image_frame.on('open',function() {
            // On open, get the id from the hidden input
            // and select the appropiate images in the media manager
            var selection =  image_frame.state().get('selection');
            var ids = jQuery('input#ik_musicdb_album_image_id').val().split(',');
            ids.forEach(function(id) {
                var attachment = wp.media.attachment(id);
                attachment.fetch();
                selection.add( attachment ? [ attachment ] : [] );
            });
        });
        
        image_frame.open();
     });

    // Ajax para cargar datos en input
    function ik_musicdb_refresh_image(img_id){
        var data = {
            action: 'ik_woomusicadb_albumimg_mediasubir',
            img_id: img_id
        };
    
        jQuery.get(ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
            if(response.success === true) {
                if (response.data !== false){
                    jQuery('#ik_musicdb_album_img_src').attr('src', response.data );
                    jQuery('#ik_musicdb_album_img').val( response.data );
                }
            }
        });
    }
    
    //Muestro los datos del resultado del guardado de datos
    var result_text = jQuery('#ik_musicdb_resultado').text();
    if (result_text !== '' && result_text !== ' ' && result_text !== 'undefined'){
        jQuery('#ik_musicdb_resultado').fadeIn(300);
        setTimeout(function(){
            jQuery('#ik_musicdb_resultado').fadeOut(600);
        }, 2000);
    }
    
    
    //Me fijo si se ingresan datos en input de album
    jQuery(document).on('keypress', 'input#ik_musicadb_album_nombre', function(){
        var text_album_val = jQuery(this).val();
        ik_musicdb_js_buscar_album(text_album_val);
    });
    jQuery(document).on('keyup', 'input#ik_musicadb_album_nombre', function(){
        var text_album_val = jQuery(this).val();
        ik_musicdb_js_buscar_album(text_album_val);
    });
    jQuery(document).on('keydown', 'input#ik_musicadb_album_nombre', function(){
        var text_album_val = jQuery(this).val();
        ik_musicdb_js_buscar_album(text_album_val);
    });
    
    //Buscador de albums existentes al escribir en el campo de albums
    function ik_musicdb_js_buscar_album(text_album_input){
        var input_album_width = parseInt(jQuery('input#ik_musicadb_album_nombre').width())+40;
        if (text_album_input !== '' && text_album_input !== ' '){
    
            //I make sure the length is more than 0
            if (text_album_input.length > 0 && text_album_input !== undefined && text_album_input !== null){
    
                var data = {
                    action: "ik_woomusicadb_buscar_album_subir",
                    "post_type": "post",
                    "text_album_input": text_album_input,
                };  
            
                jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
                        if (response !== false){
                            setTimeout(function(){
                                jQuery('#ik_musicadb_album_input ul').remove();
                                jQuery('#ik_musicadb_album_input').append('<ul></ul>');
                                jQuery('#ik_musicadb_album_input ul').attr('style', 'width: '+input_album_width+'px');
                                jQuery('#ik_musicadb_album_input ul').append(response);
                            }, 300);
                        }
            
                }, "json");
            } else {
                jQuery('#ik_musicadb_album_input ul').fadeOut(300);
                jQuery('#ik_musicadb_album_id').val('0');
                jQuery('#ik_musicadb_album_input').removeClass('ik_musicadb_albumasignado');
            }
    
        } else {
            jQuery('#ik_musicadb_album_input ul').fadeOut(300);
            jQuery('#ik_musicadb_album_id').val('0');
            jQuery('#ik_musicadb_album_input').removeClass('ik_musicadb_albumasignado');
        }
    }
    
    //Marco al album como seleccionado
    jQuery(document).on('click', '#ik_musicadb_album_input .ik_woomusicadb_album', function(){
        var album_selected = jQuery(this).attr('album_id');
        jQuery('input#ik_musicadb_album_nombre').val(jQuery(this).attr('nombre_album'));
        jQuery('#ik_musicadb_album_id').val(album_selected);
        jQuery('#ik_musicadb_album_input').addClass('ik_musicadb_albumasignado');
        jQuery('#ik_musicadb_album_input ul').remove();
    
    });
    
    //Subir canciones y crear o asignar album
    jQuery(document).on('click', '#ik_musicadb_subir_canciones', function(e){
        e.preventDefault();
        jQuery('#ik_musicadb_album_input ul').remove();
        var boton_subir = jQuery(this);
        var boton_subir_texto = jQuery(this).text();
        var album_id_val = parseInt(jQuery('#ik_musicadb_album_id').val());
        var album_nombre = jQuery('#ik_musicadb_album_nombre').val();
        
        boton_subir.prop('disable', true);
        boton_subir.text('Procesando');
        
        if (album_nombre !== '' && album_nombre !== undefined && album_nombre !== ' '){
            if (album_id_val === 0){
                var data = {
                    action: "ik_woomusicadb_crear_album_subir",
                    "post_type": "post",
                    "album_nombre": album_nombre,
                };  
            
                jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
                        if (response !== false){
                            var album_id = JSON.parse(response);
                            jQuery('#ik_musicadb_album_input ul').remove();
                            ik_musicadb_js_subir_archivos(parseInt(album_id));
                            boton_subir.prop('disable', false);
                            boton_subir.text(boton_subir_texto);
                            jQuery('#ik_musicadb_album_id').val('0');
                            jQuery('#ik_musicadb_album_nombre').val('');
                        } else {
                            alert('Error. Contactar a soporte.');
                            boton_subir.prop('disable', false);
                            boton_subir.text(boton_subir_texto);
                        }
            
                }, "json");
                
            } else {
                ik_musicadb_js_subir_archivos(album_id_val);
                boton_subir.prop('disable', false);
                boton_subir.text(boton_subir_texto);
                jQuery('#ik_musicadb_album_id').val('0');
                jQuery('#ik_musicadb_album_nombre').val('');
            }
        }
        
    });
    
    function ik_musicadb_js_subir_archivos(album_id){
		album_id = parseInt(album_id);
        var image_frame;
        if(image_frame){
            image_frame.open();
        }
        // Define image_frame as wp.media object
        image_frame = wp.media({
            title: 'Subir Canciones',
            multiple : true,
            library : {
                type : ['audio/mpeg','audio/mp3', 'audio/mpeg3','audio/x-mpeg-3','audio/wav','audio/x-wav','audio/m4a','audio/wav','audio/x-wav'],
            }
        });
    
        image_frame.on('close',function() {
            // On close, get selections and save to the hidden input
            // plus other AJAX stuff to refresh the image preview
            var selection =  image_frame.state().get('selection');
            var gallery_ids = new Array();
            var my_index = 0;
            selection.each(function(attachment) {
                gallery_ids[my_index] = attachment['id'];
                my_index++;
            });
            
            var ids = gallery_ids.join(",");
            jQuery('input#ik_musicadb_music_id').val(ids);
            ik_musicdb_subir_mp3_a_db(ids, album_id);
        });
    
        image_frame.on('open',function() {
            // On open, get the id from the hidden input
            // and select the appropiate images in the media manager
            var selection =  image_frame.state().get('selection');
            var ids = jQuery('input#ik_musicadb_music_id').val().split(',');
            ids.forEach(function(id) {
                var attachment = wp.media.attachment(id);
                attachment.fetch();
                selection.add( attachment ? [ attachment ] : [] );
            });
        });
        
        image_frame.open();
    
    }
    
    
    function ik_musicdb_subir_mp3_a_db(mp3_id, id_de_album){
		var id_de_album = parseInt(id_de_album);
        var data = {
            action: 'ik_woomusicadb_album_mp3_subir',
            mp3_id: mp3_id,
            id_de_album: id_de_album,
        };
		
    
        jQuery.get(ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
            if(response.success === true) {
                ik_musicadb_mostraralbum(id_de_album);
            }
        });
    }
    
    //Me aseguro que exista el campo a monitorear
    if (jQuery('#ik_musicadb_album_id').attr('name') == 'ik_musicadb_album_id'){
        setInterval(function(){
            var val_album_id = jQuery('#ik_musicadb_album_id').val();
            if (val_album_id != 0){
                jQuery('#ik_musicadb_album_mensaje').text('Album #'+val_album_id+' seleccionado.');
            } else {
                jQuery('#ik_musicadb_album_mensaje').text("Crear uno nuevo o escribir y seleccionar uno ya existente.");
            }
        }, 500);
    }
    //Ver info del album seleccionado
    jQuery(document).on('click', '#ik_musicadb_css_canciones .ik_woomusicadb_album_medio', function(e){
        e.preventDefault();
        var album_id_selecccionado = jQuery(this).attr('album_id');
        ik_musicadb_mostraralbum(album_id_selecccionado);
        
    });
    
    //funcion para mostrar album
    function ik_musicadb_mostraralbum(albumelemento){
		var albumelemento = parseInt(albumelemento);
        if (albumelemento != '' && albumelemento != undefined && albumelemento != '0'){
            
            jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_album_popup_content').empty();
            jQuery('#ik_musicadb_album_popup_detalles').fadeIn(500);
            jQuery('<div class="ik_musicdb_cargando">Cargando</div>').appendTo('#ik_musicadb_album_popup_detalles .ik_musicadb_album_popup_content');
        
            var data = {
                action: "ik_woomusicadb_ajax_ver_album_info",
                "post_type": "post",
                "album_id": albumelemento,
            };  
        
            jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
                    if (response != false){
                        jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_album_popup_content').empty();
                        jQuery('#ik_musicadb_album_popup_detalles').attr('album_id', albumelemento);
                        jQuery(response).appendTo('#ik_musicadb_album_popup_detalles .ik_musicadb_album_popup_content');
                    } else {
                        location.reload();
                    }
        
            }, "json");
        }
    }
    
    // function to close popups and only show one at a time
    jQuery(document).on('click', '.ik_musicdb_btn_cerrar_popup', function(){
        jQuery(".ik_music_db_popup").fadeOut(500);
		jQuery('#ik_music_db_popup').attr('album_id', '0');
    });

    	
    jQuery('#ik_musicadb_css_canciones').on('click', '#ik_musicadb_guardar_cambios_album', function(){
        jQuery(".ik_music_db_popup").fadeOut(500);
		jQuery('#ik_music_db_popup').attr('album_id', '0');
    });

    // function to close popups and only show one at a time
    jQuery(document).on('click', '.ik_musicdb_btn_cerrar_popup', function(){
        jQuery(".ik_music_db_popup").fadeOut(500);
        jQuery('#ik_music_db_popup').attr('album_id', '0');
    });
    
    //Subir canciones asignando a album existente
    jQuery('body').on('click', '.ik_woomusicadb_agregar_canciones', function(e){
        e.preventDefault();
        var album_id_val = jQuery(this).attr('album_id');
        		
        ik_musicadb_js_subir_archivos(album_id_val);
        
    });
    
	//funcion para eliminar album
    jQuery('body').on('click', '#ik_musicadb_eliminar_album', function(){        
		var album_id = jQuery(this).attr('album_id');
		if (confirm("Seguro de eliminar el abum #"+album_id)) {
	
			var data = {
				action: "ik_woomusicadb_ajax_eliminar_album_info",
				"post_type": "post",
				"album_id": album_id,
			};  
		
			jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
					if (response != false){
						jQuery(".ik_music_db_popup").fadeOut(500);
						jQuery('#ik_musicadb_css_albums_contenido').load('#ik_musicadb_css_canciones .ik_musicadb_css_album_subidos');
					}
		
			}, "json");
		}
    });
	
	//Funcion para reproducir cancion
	jQuery('body').on('click', '#ik_music_db_album_columna_canciones .canciones_acciones', function(){
		var cancion_id = jQuery(this).parent().attr('cancion_id');
		var elemento_cancion = jQuery(this).find('.dashicons');
		
		if (jQuery(elemento_cancion).attr('accion') != 'on'){
			var data = {
				action: "ik_woomusicadb_ajax_reproducir_cancion",
				"post_type": "post",
				"cancion_id": cancion_id,
			};  
		
			jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
					if (response != 'error'){
						jQuery('#ik_musicadb_album_reproductor').addClass('activo');
						jQuery('#ik_musicadb_album_reproductor').attr('cancion_id', cancion_id);
						ik_musicadb_script_reproducir(response.url, cancion_id);
						
						jQuery(elemento_cancion).removeClass('dashicons-controls-play');
						jQuery(elemento_cancion).addClass('dashicons-controls-pause');
						
						jQuery('#ik_musicadb_album_reproductor').empty();
						jQuery('#ik_musicadb_album_reproductor').append('<button class="reproductor_control" estado="on"><div class="columna_reproductor controles_reproductor"><span class="dashicons dashicons-controls-pause"></span></button><div class="duracion_cancion"><span class="cancion_reproduciendo"></span><span class="cancion_tiempototal"></span></div><div class="columna_reproductor datos_reproductor"><span class="titulo_reproductor">'+response.titulo+'</span><span class="autor-reproductor">'+response.autor+'</span></div></div>');
						jQuery(elemento_cancion).attr('accion', 'on');		
					} else {
						alert('Archivo Incorrecto');
					}
		
			}, "json");

		} else {
			ik_musicadb_pausar_musica(elemento_cancion);
		}
	});
	
	//Iniciar cancion
	var cancionRep = new Audio('');
	
	//si la cancion cambia
	cancionRep.addEventListener('loadstart', function(){ 
		var cancion_id_actual = jQuery('#ik_musicadb_album_reproductor').attr('cancion_id');
		
		//Pongo en play todas las pistas menos la reproduccion actual
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_lista_canciones li').each(function() {
			if (jQuery(this).attr('cancion_id') != cancion_id_actual){
				jQuery(this).find('.dashicons').removeClass('dashicons-controls-pause');
				jQuery(this).find('.dashicons').addClass('dashicons-controls-play');
			}
		});
	});
	
	function ik_musicadb_reproducir_musica(elemento_cancion){
		cancionRep.play();

		jQuery('#ik_musicadb_album_reproductor .reproductor_control .dashicons').removeClass('dashicons-controls-play');
		jQuery('#ik_musicadb_album_reproductor .reproductor_control .dashicons').addClass('dashicons-controls-pause');
		jQuery('#ik_musicadb_album_reproductor .reproductor_control').attr('estado', 'on');
		elemento_cancion.removeClass('dashicons-controls-play');
		elemento_cancion.addClass('dashicons-controls-pause');		
		jQuery(elemento_cancion).attr('accion', 'on');		
	}
	
	function ik_musicadb_pausar_musica(elemento_cancion){
		cancionRep.pause();
		
		jQuery('#ik_musicadb_album_reproductor .reproductor_control .dashicons').removeClass('dashicons-controls-pause');
		jQuery('#ik_musicadb_album_reproductor .reproductor_control .dashicons').addClass('dashicons-controls-play');	
		jQuery('#ik_musicadb_album_reproductor .reproductor_control').attr('estado', 'off');
		elemento_cancion.removeClass('dashicons-controls-pause');
		elemento_cancion.addClass('dashicons-controls-play');	
		jQuery(elemento_cancion).attr('accion', 'off');				
	}
	
	//Para o empezar reproduccion
	jQuery('body').on('click', '#ik_musicadb_album_reproductor .reproductor_control', function(){
		var estado_rep = jQuery('#ik_musicadb_album_reproductor .reproductor_control').attr('estado');
		
		var cancion_id = jQuery('#ik_musicadb_album_reproductor').attr('cancion_id');
		var elemento_cancion = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_lista_canciones li[cancion_id='+cancion_id+'] .dashicons');
		
		if (estado_rep == 'off'){
			ik_musicadb_reproducir_musica(elemento_cancion);
		} else {
			ik_musicadb_pausar_musica(elemento_cancion);				
		}
	});

	//Reproduccion de canciones
	function ik_musicadb_script_reproducir(url_cancion){		
		cancionRep.setAttribute("src", url_cancion);

		cancionRep.oncanplaythrough = function(){
			
			var cancion_id = jQuery('#ik_musicadb_album_reproductor').attr('cancion_id');
			cancionRep.play();
			var duration = cancionRep.duration;
			var duracion_cancion_min = Math.floor(duration / 60);
			var duracion_cancion_min = (duracion_cancion_min >= 10) ? duracion_cancion_min : "0" + duracion_cancion_min;
			var duracion_cancion_sec = Math.floor(duration % 60);
			var duracion_cancion_sec = (duracion_cancion_sec >= 10) ? duracion_cancion_sec : "0" + duracion_cancion_sec;			
			var duracion_cancion = duracion_cancion_min +':'+duracion_cancion_sec;

			
			jQuery('#ik_musicadb_album_reproductor .cancion_tiempototal').text('-'+duracion_cancion);
	
			cancionRep.addEventListener('timeupdate', function(){ ik_actualizar_tiempo(); });
			
			function ik_actualizar_tiempo(){
				
				var currentTime = cancionRep.currentTime;
				
				var cancion_reproduciendo_min = Math.floor(currentTime / 60);
				var cancion_reproduciendo_min = (cancion_reproduciendo_min >= 10) ? cancion_reproduciendo_min : "0" + cancion_reproduciendo_min;
				var cancion_reproduciendo_sec = Math.floor(currentTime % 60);
				var cancion_reproduciendo_sec = (cancion_reproduciendo_sec >= 10) ? cancion_reproduciendo_sec : "0" + cancion_reproduciendo_sec;
				var cancion_reproduciendo = cancion_reproduciendo_min +':'+cancion_reproduciendo_sec;
				jQuery('#ik_musicadb_album_reproductor .cancion_reproduciendo').text(cancion_reproduciendo);	
						
			}
			
			return false;
		}

		//cancionRep.loop = true;

		cancionRep.onended = function(){
			jQuery('#ik_musicadb_album_reproductor .reproductor_control').attr('estado', 'off');
			jQuery('#ik_musicadb_album_reproductor .reproductor_control .dashicons').removeClass('dashicons-controls-pause');
			jQuery('#ik_musicadb_album_reproductor .reproductor_control .dashicons').addClass('dashicons-controls-play');
			cancionRep.pause();
			
			var cancion_id = jQuery('#ik_musicadb_album_reproductor').attr('cancion_id');
			var elemento_cancion = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_lista_canciones li[cancion_id='+cancion_id+'] .dashicons');

			elemento_cancion.removeClass('dashicons-controls-pause');
			elemento_cancion.addClass('dashicons-controls-play');
		}

	}
	
	jQuery('body').on('click', '#ik_musicadb_album_popup_detalles #ik_woomusicadb_editar_fotos_album', function(){
		var album_id = jQuery('#ik_musicadb_album_popup_detalles').attr('album_id');
        var image_frame;
        if(image_frame){
            image_frame.open();
        }
		
        var data = {
            action: 'ik_woomusicadb_ajax_album_get_img_ids',
            album_id: album_id,
        };
		
    
        jQuery.get(ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
			if (response){
			
				if (response != 'no'){
					
					var img_ids_incluir =  jQuery.map(response.split(','), function(value){
						return parseInt(value);
					});
					
					// Define image_frame as wp.media object
					image_frame = wp.media({
						title: 'Subir Fotos de Portada',
						multiple : true,	
						id : 'ik_musicadb_script_limit_imgs',
						library : {
							type : 'image'
						}
					});
						
				} else {
					// Define image_frame as wp.media object
					image_frame = wp.media({
						title: 'Subir Fotos de Portada',
						multiple : true,	
						id : 'ik_musicadb_script_limit_imgs',
						library : {
							type : 'image'
						}
					});

				}					
						
			
				image_frame.on('close',function() {
					// On close, get selections and save to the hidden input
					// plus other AJAX stuff to refresh the image preview
					var selection =  image_frame.state().get('selection');
					var gallery_ids = new Array();
					var my_index = 0;
					selection.each(function(attachment) {
						gallery_ids[my_index] = attachment['id'];
						my_index++;
					});
					
					
					var ids = gallery_ids.join(",");
					jQuery('#ik_musicadb_album_popup_detalles #ik_woomusicadb_editar_fotos_album').val(ids);
					ik_musicdb_subir_imgs_album(ids, album_id);
				});
					jQuery( 'body' ).on( 'click', '#ik_musicadb_script_limit_imgs .attachments-browser .attachment.save-ready', function() {
						if (jQuery(this).attr('aria-checked') == 'true'){
							jQuery('.attachments-browser li.selected').each(function(i) {
								if (i > 3){
									jQuery(this).removeClass('selected');
									jQuery(this).attr('aria-checked', 'false');
								}
							});
						}
					});
				image_frame.on('open',function() {
					var selection =  image_frame.state().get('selection');
					var ids = jQuery('#ik_musicadb_album_popup_detalles #ik_woomusicadb_editar_fotos_album').val().split(',');
					ids.forEach(function(id) {
						var attachment = wp.media.attachment(id);
						attachment.fetch();
						selection.add( attachment ? [ attachment ] : [] );
					});
					
					
						if (img_ids_incluir){
							
							img_ids_incluir.forEach(function(id) {
								let attachment = wp.media.attachment(id);
								selection.add(attachment ? [attachment] : []);
							});

						}
					
				});

				image_frame.open();	
			}
        });		
	});
	
	function ik_musicdb_subir_imgs_album(ids_imgs, album_id){

		var album_id = parseInt(album_id);
        var data = {
            action: 'ik_woomusicadb_ajax_album_subir_imgs',
            ids_imgs: ids_imgs,
            album_id: album_id,
        };
		
    
        jQuery.get(ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
            if(response) {
                ik_musicadb_mostraralbum(album_id);
            }
        });
	}
	
	jQuery('body').on('click', '#ik_musicadb_album_popup_detalles .ik_musicadb_mostrar_img_galeria', function(){
		var foto_a_pasar = jQuery(this).attr('seleccion_foto');
		jQuery('#ik_musicadb_album_popup_detalles .ik_woomusicadb_album_portada_detalles img').removeClass('album_foto_activa');
		jQuery('#ik_musicadb_album_popup_detalles .ik_woomusicadb_album_portada_detalles img').addClass('album_foto_inactiva');
		jQuery('#ik_musicadb_album_popup_detalles .ik_woomusicadb_album_portada_detalles .'+foto_a_pasar).removeClass('album_foto_inactiva');
		jQuery('#ik_musicadb_album_popup_detalles .ik_woomusicadb_album_portada_detalles .'+foto_a_pasar).addClass('album_foto_activa');
	});
	
	//I show images in overlay
	jQuery('body').on('click', '.ik_musicadb_overlay', function(){
		var image_src = jQuery(this).attr('src');
		jQuery('#ik_musicadb_popup_overlay').remove('');
		jQuery('body').attr('style', 'overflow:hidden');
		jQuery('body').append('<div id="ik_musicadb_popup_overlay"><div class="ik_musicdb_btn_cerrar_popup_overlay"><span class="dashicons dashicons-dismiss"></span></div><img src="'+image_src+'" alt="imagen overlay" /></div>');
		
	});
	jQuery('body').on('click', '.ik_musicdb_btn_cerrar_popup_overlay', function(){
		var image_src = jQuery(this).attr('src');
		jQuery('#ik_musicadb_popup_overlay').remove('');
		jQuery('body').removeAttr('style');
		
	});
	//Edicion titulo
	jQuery('body').on('click', '#ik_musicadb_album_popup_detalles #ik_musicadb_editar_titulo', function(){
		//Cancelo ediciones activas
		ik_music_db_script_cancelar_edicion();
		
		//Remuevo el boton de editar
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_titulo_album').removeClass('ik_musicadb_transition_hover');
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_titulo_album').addClass('ik_musicadb_transition_editando');


		var input_texto = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_titulo_album_input').attr('dato_valor');
		
		if (input_texto == undefined){
			var input_texto = '';
		}
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_titulo_album_input').html('<input type="text" value="'+input_texto+'" placeholder="Ingresar Nombre"><button dato="nombre" id="ik_musicadb_boton_guardar_datos_album" class="button">Guardar</button><button dato="titulo" id="ik_musicadb_boton_cancelar_guardar_datos" viejo_valor="'+input_texto+'" class="button ik_musicadb_cancelar">Cancelar</button>');
	});
	//Edicion interpretes
	jQuery('body').on('click', '#ik_musicadb_album_popup_detalles #ik_musicadb_editar_interpretes', function(){
		//Cancelo ediciones activas
		ik_music_db_script_cancelar_edicion();
		
		//Remuevo el boton de editar
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_interpretes_album').removeClass('ik_musicadb_transition_hover');
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_interpretes_album').addClass('ik_musicadb_transition_editando');

		var input_texto = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_interpretes_album_input').attr('dato_valor');
		if (input_texto == undefined){
			var input_texto = '';
		}
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_interpretes_album_input').html('<input type="text" value="'+input_texto+'" placeholder="Int&eacute;rpretes"><button dato="interpretes" id="ik_musicadb_boton_guardar_datos_album" class="button">Guardar</button><button dato="interpretes" id="ik_musicadb_boton_cancelar_guardar_datos" viejo_valor="'+input_texto+'" class="button ik_musicadb_cancelar">Cancelar</button>');
	});
	//Edicion year
	jQuery('body').on('click', '#ik_musicadb_album_popup_detalles #ik_musicadb_editar_year', function(){
		//Cancelo ediciones activas
		ik_music_db_script_cancelar_edicion();

		//Remuevo el boton de editar
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_year_album').removeClass('ik_musicadb_transition_hover');
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_year_album').addClass('ik_musicadb_transition_editando');

		var input_texto = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_year_album_input').attr('dato_valor');
		if (input_texto == undefined){
			var input_texto = '';
		}		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_year_album_input').html('<input type="text" value="'+input_texto+'" placeholder="Ingresar A&ntilde;o"><button dato="year" id="ik_musicadb_boton_guardar_datos_album" class="button">Guardar</button><button dato="year" id="ik_musicadb_boton_cancelar_guardar_datos" viejo_valor="'+input_texto+'" class="button ik_musicadb_cancelar">Cancelar</button>');
	});
	//Edicion genero
	jQuery('body').on('click', '#ik_musicadb_album_popup_detalles #ik_musicadb_editar_genero', function(){
		//Cancelo ediciones activas
		ik_music_db_script_cancelar_edicion();

		//Remuevo el boton de editar
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_genero_album').removeClass('ik_musicadb_transition_hover');
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_genero_album').addClass('ik_musicadb_transition_editando');


		var input_texto = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_genero_album_input').attr('dato_valor');
		if (input_texto == undefined){
			var input_texto = '';
		}		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_genero_album_input').html('<input type="text" value="'+input_texto+'" placeholder="Ingresar G&eacute;nero"><button dato="genero" id="ik_musicadb_boton_guardar_datos_album" class="button">Guardar</button><button dato="genero" id="ik_musicadb_boton_cancelar_guardar_datos" viejo_valor="'+input_texto+'" class="button ik_musicadb_cancelar">Cancelar</button>');
	});
	//Edicion descripcion
	jQuery('body').on('click', '#ik_musicadb_album_popup_detalles #ik_musicadb_editar_descripcion', function(){
		//Cancelo ediciones activas
		ik_music_db_script_cancelar_edicion();
		
		//Remuevo el boton de editar
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_descripcion_album').removeClass('ik_musicadb_transition_hover');
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_descripcion_album').addClass('ik_musicadb_transition_editando');

		var input_texto = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_descripcion_album_input').attr('dato_valor');
		if (input_texto == undefined){
			var input_texto = '';
		}		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_descripcion_album_input').html('<textarea placeholder="Ingresar Descripci&oacute;n">'+input_texto+'</textarea><button dato="descripcion" id="ik_musicadb_boton_guardar_datos_album" class="button">Guardar</button><button dato="descripcion" id="ik_musicadb_boton_cancelar_guardar_datos" viejo_valor="'+input_texto+'" class="button ik_musicadb_cancelar">Cancelar</button>');
	});
	
	//Guardo datos editados del album
	jQuery('body').on('click', '#ik_musicadb_album_popup_detalles #ik_musicadb_boton_guardar_datos_album', function(){
		var dato_ingresado = jQuery(this).attr('dato');

		if (dato_ingresado == 'nombre'){
			var input_ingresado = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_titulo_album_input input').val();
		} else if (dato_ingresado == 'interpretes'){
			var input_ingresado = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_interpretes_album_input input').val();
		} else if (dato_ingresado == 'year'){
			var input_ingresado = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_year_album_input input').val();
		} else if (dato_ingresado == 'genero'){
			var input_ingresado = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_genero_album_input input').val();
		} else {
			//Descripcion
			var input_ingresado = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_descripcion_album_input textarea').val();
		}
				
		var album_id = parseInt(jQuery('#ik_musicadb_album_popup_detalles').attr('album_id'));

        var data = {
            action: 'ik_woomusicadb_ajax_album_editar_datos',
			"post_type": "post",
            "dato_ingresado": dato_ingresado,
            "album_id": album_id,
			"input_ingresado": input_ingresado,
        };
		
    
        jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
            if(response) {
                ik_musicadb_mostraralbum(album_id);
            }
        }, "json");
	
	});
	
	//Funcion para cancelar ediciones activas
	function ik_music_db_script_cancelar_edicion(){
		var elemento_cancelar = jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_transition_editando');
		var boton_cancelar = jQuery('#ik_musicadb_album_popup_detalles #ik_musicadb_boton_cancelar_guardar_datos');
		var viejo_valor = boton_cancelar.attr('viejo_valor');
		var dato = boton_cancelar.attr('dato');
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_'+dato+'_album_input').remove()
		elemento_cancelar.append('<span class="ik_musicadb_'+dato+'_album_input ik_musica_db_campo_editar" dato_valor="'+viejo_valor+'">'+viejo_valor+'</span>');
		
		//Vuelvo a agregar el boton de editar en hover
		jQuery('#ik_musicadb_album_popup_detalles .ik_woomusicadb_album_medio_detalles div').addClass('ik_musicadb_transition_hover');
		jQuery('#ik_musicadb_album_popup_detalles .ik_woomusicadb_album_medio_datos div').removeClass('ik_musicadb_transition_hide');
		jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_transition_editando').removeClass('ik_musicadb_transition_editando');		
	}

	//Cancelo operacion de editar datos
	jQuery('body').on('click', '#ik_musicadb_album_popup_detalles #ik_musicadb_boton_cancelar_guardar_datos', function(){
		ik_music_db_script_cancelar_edicion();		
	});

    jQuery('#ik_musicadb_css_subidor_masa').on('click', '#ik_musicadb_album_zip_files_btn', function(){
        document.body.onfocus = ik_musicadb_js_InputFileActivity;
        jQuery('#ik_musicadb_css_procesamiento_zip p').text('Seleccionando discos a subir...');
        jQuery('#ik_musicadb_css_procesamiento_zip').fadeIn(600);
    });

    function ik_musicadb_js_InputFileActivity(){
        setTimeout(function(){ 
        var files_input = jQuery('#ik_musicadb_album_zip_files').val();
            
            if (files_input.length) {
                jQuery('#ik_musicadb_album_zip_subir_files_btn').prop('disabled', false);
                jQuery('#ik_musicadb_css_procesamiento_zip p').text('Hacer click en "Subir Archivos Zip"...');
            } else {
                jQuery('#ik_musicadb_album_zip_files_btn').prop('disabled', false);
                jQuery('#ik_musicadb_css_procesamiento_zip').fadeOut(600);
            }
            document.body.onfocus = null;
        }, 1000);
    }
    
    jQuery('#ik_musicadb_css_subidor_masa').on('click', '#ik_musicadb_album_zip_subir_files_btn', function(){
        jQuery('#ik_musicadb_album_zip_files_btn').prop('disabled', true);
        jQuery(this).prop('disabled', true);
        jQuery('#ik_musicadb_css_procesamiento_zip').addClass('ik_musicdb_cargando');
        jQuery('#ik_musicadb_css_procesamiento_zip p').text('Subiendo archivos zip...');
        jQuery('#ik_musicadb_album_zip_resetear_subir_btn').fadeIn(600);
        
        var inputfile = jQuery('#ik_musicadb_album_zip_files');

        var countinputfiles = parseInt(inputfile.prop('files').length);
        var cantarchivos = countinputfiles - 1;
        jQuery('#ik_musicadb_css_subidor_masa').attr('iarchivos', '0');
        jQuery('#ik_musicadb_css_subidor_masa').attr('cantarchivos', cantarchivos);
        jQuery('#ik_musicadb_css_subidor_masa').attr('archivos_procesados', '0');
        jQuery('#ik_musicadb_css_subidor_masa').attr('archivos_fallados', '0');
        
        for (var i = 0; i < countinputfiles; ++i) {
            zipfile = new FormData();
            var zipfile_data = jQuery('#ik_musicadb_album_zip_files').prop('files')[i]
            zipfile.append('file', zipfile_data);
            zipfile.append('action', 'ik_woomusicadb_subir_zip_album');

            const fileSize = zipfile_data.size;
            const waitTime = calculateWaitTime(fileSize);
            if(i == 0){
                jQuery('#ik_musicadb_css_procesamiento_zip p').text('Procesando...');
            }
            
            ik_process_waitTime(waitTime);
            
            jQuery.ajax({
                url: ik_musicdb_ajaxurl.ajaxurl,
                type: 'POST',
                contentType: false,
                processData: false,
                data: zipfile,
                success: function (response) {
                    if (typeof response.data.name !== 'undefined'){
                        var zip_name = response.data.name;
                        var file_name = response.data.file_name;
                        var album_dir = response.data.fileroot;
                        
                        jQuery('#ik_musicadb_css_procesamiento_zip p').text('Archivo "'+zip_name+'" subido y siendo procesado.');
                        
                        var data = {
                            action: "ik_woomusicadb_crear_album_zip",
                            "post_type": "post",
                            "file_name": file_name,
                            "album_dir": album_dir,
                            "zip_name": zip_name,
                        };  
                    
                        jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
                                if (typeof response.mensaje !== 'undefined'){
                                    setTimeout(function(){
                                        jQuery('#ik_musicadb_css_procesamiento_zip p').text(htmlDecode(response.mensaje));
                                        
                                        setTimeout(function(){
                                            if (response.result == 'error'){
                                                ik_woomusicadb_js_marcar_procesado('error');
                                            } else {
                                                ik_woomusicadb_js_marcar_procesado('ok');
                                            }
                                        }, 1000);
                                    }, 2000);
                                } else {
                                    ik_woomusicadb_js_marcar_procesado('error');
                                }
                    
                        }, "json")
                        .fail(function() {
                            setTimeout(function(){
                                jQuery('#ik_musicadb_css_procesamiento_zip p').text('Hubo un error de servidor. Probar nuevamente en unos minutos.');           
                                jQuery('#ik_musicadb_css_procesamiento_zip').removeClass('ik_musicdb_cargando');  
                            }, 2000);
                        });
                        
                    } else {
                        jQuery('#ik_musicadb_css_procesamiento_zip p').text(response.data);
                        ik_woomusicadb_js_marcar_procesado('error');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    if(jqXHR.status == 503) {
                        setTimeout(function(){
                            jQuery('#ik_musicadb_css_procesamiento_zip p').text('Hubo un error de servidor. Probar nuevamente dentro de unos minutos.');
                            jQuery('#ik_musicadb_css_procesamiento_zip').removeClass('ik_musicdb_cargando');     
                        }, 2000);
                    } else {
                        setTimeout(function(){
                            jQuery('#ik_musicadb_css_procesamiento_zip p').text('El proceso no ha terminado correctamente. Chequear albums subidos y probar nuevamente en unos minutos.');
                            jQuery('#ik_musicadb_css_procesamiento_zip').removeClass('ik_musicdb_cargando');  
                        }, 2000);   
                    }                 
                }
            });
        }

    });
    
    function ik_woomusicadb_js_marcar_procesado(resultado){
        
        var counter = parseInt(jQuery('#ik_musicadb_css_subidor_masa').attr('iarchivos'));
        var cant = parseInt(jQuery('#ik_musicadb_css_subidor_masa').attr('cantarchivos'));
        var resultado_ok = parseInt(jQuery('#ik_musicadb_css_subidor_masa').attr('archivos_procesados'));
        var resultado_error = parseInt(jQuery('#ik_musicadb_css_subidor_masa').attr('archivos_fallados'));
        
        if (resultado == 'ok'){
            resultado_ok = resultado_ok + 1; 
            jQuery('#ik_musicadb_css_subidor_masa').attr('archivos_procesados', resultado_ok);
        } else {
            resultado_error = resultado_error + 1; 
            jQuery('#ik_musicadb_css_subidor_masa').attr('archivos_fallados', resultado_error);
        }
        
        
        counter = counter + 1;
        jQuery('#ik_musicadb_css_subidor_masa').attr('iarchivos', counter);
        
        
        cant = cant + 1;
        
        if (counter == cant){
            setTimeout(function(){
                jQuery('#ik_musicadb_css_procesamiento_zip').removeClass('ik_musicdb_cargando');
                var mensaje_proceso_terminado = '';
                if (resultado_ok > 0){
                    
                    if (resultado_ok > 1){
                        mensaje_proceso_terminado = '<p>'+ resultado_ok +' albums subidos.</p>';
                    } else {
                        mensaje_proceso_terminado = '<p>'+htmlDecode('1 &Aacute;lbum subido con &eacute;xito.')+'</p>';
                    }
                }
                if (resultado_error > 0){
                    
                    if (resultado_error > 1){
                        mensaje_proceso_terminado = mensaje_proceso_terminado+'<p>'+ resultado_error +' archivos no fueron procesados correctamente.</p>';
                    } else {
                        mensaje_proceso_terminado = mensaje_proceso_terminado + '<p>'+htmlDecode('1 &Aacute;lbum no pudo ser subido.')+'</p>';
                    }
                }
                jQuery('#ik_musicadb_css_procesamiento_zip').empty();
                if (mensaje_proceso_terminado !== ''){
                    jQuery('#ik_musicadb_css_procesamiento_zip').html(mensaje_proceso_terminado);
                } else {
                    jQuery('#ik_musicadb_css_procesamiento_zip').html('<p>Archivos subidos.</p>');
                }
            
                jQuery('#ik_musicadb_album_zip_resetear_subir_btn').addClass('restablecer');
                jQuery('#ik_musicadb_album_zip_resetear_subir_btn').text(htmlDecode('Subir m&aacute;s archivos'));
                
            }, 3000);
        } else {
            if (jQuery('#ik_musicadb_css_procesamiento_zip .status').length){
                jQuery('#ik_musicadb_css_procesamiento_zip .status').text(counter+' archivos procesados de '+cant);
            } else {
                jQuery('#ik_musicadb_css_procesamiento_zip').append('<span class="status">'+counter+' archivo procesado de '+cant+'</span>');
            }
            
            
        }
    }
    
    jQuery('#ik_musicadb_css_subidor_masa').on('click', '#ik_musicadb_album_zip_resetear_subir_btn', function(){
        if (!jQuery(this).hasClass('restablecer')){
            jQuery(this).text('Cancelando');
            if (confirm("Confirmar para cancelar procedimiento.") === true){
                jQuery('#ik_musicadb_css_procesamiento_zip').fadeOut(600);
                if (typeof xhr !== 'undefined'){
                    xhr.abort();
                }
            }
        }
        
        location.reload();
    });
    jQuery('#ik_musicadb_album_popup_detalles').on('click', '.ik_editar_cancion', function(){
        var cancion_editar = jQuery(this).parent().parent().find('.cancion_editar'); 
        var botones_editar = jQuery(this).parent().parent().find('.editar_opciones_cancion'); 
        var boton_play = jQuery(this).parent().parent().find('.canciones_acciones'); 
        var cancion_id = jQuery(this).parent().parent().attr('cancion_id'); 

        const cancion_array = cancion_editar.text().split('- ');
        
        var cancion_inputs_editar= '<div class="ik_campos_cancion_editar">'
        
        cancion_inputs_editar = cancion_inputs_editar+'<input type="number" name="ntrack" class="ntrack_editar_cancion" original_value="'+cancion_array[0]+'" value="'+cancion_array[0]+'">';
        cancion_inputs_editar = cancion_inputs_editar+'<input type="text" class="nombre_editar_cancion" original_value="'+cancion_array[1]+'" value="'+cancion_array[1]+'">';
        cancion_inputs_editar = cancion_inputs_editar + '<button class="editar_cancion_guardar button" cancion_id="'+cancion_id+'"><span class="dashicons dashicons-yes"></span></button>';
        cancion_inputs_editar = cancion_inputs_editar + '<button class="editar_cancion_cancelar button" cancion_id="'+cancion_id+'"><span class="dashicons dashicons-undo"></span></button></div>';
        botones_editar.attr('style', 'display: none');
        cancion_editar.attr('style', 'width: 100%; max-width: 100%');
        boton_play.attr('style', 'display: none');
        cancion_editar.html(cancion_inputs_editar);

    });

    jQuery('#ik_musicadb_album_popup_detalles').on('click', '.editar_cancion_cancelar', function(){
        var cancion_editar = jQuery(this).parent().parent(); 
        var botones_editar = cancion_editar.parent().parent().find('.editar_opciones_cancion'); 
        var boton_play = cancion_editar.parent().parent().find('.canciones_acciones'); 
        var ntrack = cancion_editar.find('.ntrack_editar_cancion').attr('original_value'); 
        var nombre_cancion = cancion_editar.find('.nombre_editar_cancion').attr('original_value'); 
        var texto_cancion = ntrack+'- '+nombre_cancion;
        cancion_editar.removeAttr('style');
        botones_editar.removeAttr('style');
        boton_play.removeAttr('style');
        cancion_editar.text(texto_cancion);

    });

    jQuery('#ik_musicadb_album_popup_detalles').on('click', '.editar_cancion_guardar', function(){
        var cancion_id = jQuery(this).parent().parent().parent().attr('cancion_id'); 
        var cancion_editar = jQuery(this).parent().parent(); 
        var botones_editar = cancion_editar.parent().parent().find('.editar_opciones_cancion'); 
        var boton_play = cancion_editar.parent().parent().find('.canciones_acciones'); 
        var ntrack = cancion_editar.find('.ntrack_editar_cancion').val(); 
        var nombre_cancion = cancion_editar.find('.nombre_editar_cancion').val(); 
        cancion_editar.find('.ntrack_editar_cancion').prop('disabled', true);
        cancion_editar.find('.nombre_editar_cancion').prop('disabled', true);
        cancion_editar.find('.editar_cancion_guardar').prop('disabled', true);
        cancion_editar.find('.editar_cancion_cancelar').prop('disabled', true);

        var data = {
            action: "ik_woomusicadb_editar_cancion",
            "post_type": "post",
            "cancion_id": cancion_id,
            "ntrack": ntrack,
            "nombre_cancion": nombre_cancion,
        };  
        
        jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
                if (response !== false){
                    var texto_cancion = ntrack+'- '+nombre_cancion;
                    botones_editar.removeAttr('style');
                    boton_play.removeAttr('style');
                    cancion_editar.removeAttr('style');
                    cancion_editar.text(texto_cancion);
                } else {
                    location.reload();
                }
    
        }, "json");

    });
    
    
    jQuery('#ik_musicadb_album_popup_detalles').on('click', '.ik_eliminar_cancion', function(){
        var cancion_id = jQuery(this).parent().parent().attr('cancion_id'); 
        var cancion_eliminar = jQuery(this).parent().parent().find('.cancion_editar').text(); 
        jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_editar_cancion_popup').attr('style', 'display: none');
        
        if (confirm(htmlDecode('&iquest;Seguro de eliminar la canci&oacute;n "'+cancion_eliminar+'"?'))) {
            
            var eliminar_archivo = confirm(htmlDecode("&iquest;Quer&eacute;s tambi&eacute;n borrar el archivo del sitio?"));
            
            if (eliminar_archivo == true){
                var eliminarTodosLados = 1;
            } else {
                var eliminarTodosLados = 0;
            }
            
            var data = {
                action: "ik_woomusicadb_eliminar_cancion",
                "post_type": "post",
                "cancion_id": cancion_id,
                "eliminarTodosLados": eliminarTodosLados,
            };  
        
            jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
                    if (response){
                        jQuery('#ik_musicadb_album_popup_detalles .ik_musicadb_lista_canciones li[cancion_id='+cancion_id+']').remove();
                    }
        
            }, "json");
        }
    });

    jQuery('#ik_musicadb_css_albums_contenido .ik_woomusicadb_album_medio_box').on('click', '.ik_woomusicadb_agregar_fav', function(){
        var album_id = jQuery(this).parent().find('.ik_woomusicadb_album_medio').attr('album_id');
        var fav_button = jQuery(this);
        var valor_fav = fav_button.attr('fav');
            
        var data = {
            action: "ik_woomusicadb_album_agregar_quitar_fav",
            "post_type": "post",
            "album_id": album_id,
            "valor_fav": valor_fav,
        };  
    
        jQuery.post( ik_musicdb_ajaxurl.ajaxurl, data, function(response) {
                if (response){
                    if (response == true){
                        fav_button.attr('fav', '1');
                        fav_button.html('<span class="dashicons dashicons-star-filled"></span>');
                    } else {
                        fav_button.attr('fav', '0');
                        fav_button.html('<span class="dashicons dashicons-star-empty"></span>');
                    }
                } else {
                    fav_button.attr('fav', '0');
                    fav_button.html('<span class="dashicons dashicons-star-empty"></span>');                    
                }
    
        }, "json");
    });
    
    jQuery('.ik_musicadb_panel_buscar').on('click', '.icono_busqueda', function(){
        var barra_buscar = jQuery(this).parent().find('.ik_musicadb_panel_buscador_albums');
        jQuery(this).fadeOut(600);
        setTimeout(function(){
            barra_buscar.fadeIn(500);
        }, 650);
    });
    
});