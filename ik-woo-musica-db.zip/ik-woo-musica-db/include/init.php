<?php
/*
Template: Init IK Woo Musica
Author: Gabriel Caroprese / Inforket.com
Update Date: 06/04/2021
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

// Mensaje si Woocommerce no está configurado
add_action( 'admin_notices', 'ik_woomusicadb_dependencies' );
function ik_woomusicadb_dependencies() {
    if (!class_exists('woocommerce')) {
    echo '<div class="error"><p>' . __( 'Atención: El plugin "IK Woo Musica" depende de tener instalado y activado Woocommerce para funcionar correctamente.' ) . '</p></div>';
    }
}

// Creo tablas de base de datos del plugin
function ik_woomusicadb_config_db_files() {
    
    //Creo carpeta de archivos temporales
    $upload = wp_upload_dir();
    $upload_dir = $upload['basedir'];
    $upload_dir = $upload_dir . '/'.IK_WOOMUSICADB_ARCHIVOS_TEMP;
    if (! is_dir($upload_dir)) {
       mkdir( $upload_dir, 0755 );
    }

    //Create index file to avoid navigation
    $index_file_path_temp = $upload_dir .'/index.php';

    // Verify if exists file to avoid navigation no matter what
    if ( ! file_exists( $index_file_path_temp ) ) {
        $content_index_temp = '<?php 
        //silence is golden 
        ?>';
        file_put_contents( $index_file_path_temp, $content_index_temp );
    }

    //Creo carpeta de archivos temporales de reproduccion
    $upload = wp_upload_dir();
    $upload_dir = $upload['basedir'];
    $upload_dir = $upload_dir . '/'.IK_WOOMUSICADB_ARCHIVOS_TEMP_PLAY;
    if (! is_dir($upload_dir)) {
        mkdir( $upload_dir, 0755 );
    }

    $index_file_path_play = $upload_dir .'/index.php';

    if ( ! file_exists( $index_file_path_play ) ) {
        $content_index_temp_play = '<?php 
        //silence is golden 
        ?>';
        file_put_contents( $index_file_path_play, $content_index_temp_play );
    }

    //Creo la tablas en la base de datos
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$table_name1 = $wpdb->prefix . 'ik_musicadb_canciones';
	$table_name2 = $wpdb->prefix . 'ik_musicadb_albums';

	$sql = "CREATE TABLE $table_name1 (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		titulo tinytext NOT NULL,
		interpretes tinytext NOT NULL,
		band tinytext NOT NULL,
		album_id bigint(20) NOT NULL,
		attachment_id bigint(20) NOT NULL,
		album tinytext NOT NULL,
		year int(4) NOT NULL,
	    numero_pista varchar(12) NOT NULL,
	    genero tinytext NOT NULL,
	    duracion_segundos int(6) NOT NULL,
		duracion varchar(12),
		tiempo_subido datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		tiempo_editado datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		descripcion longtext,
		url_audio longtext,
		UNIQUE KEY id (id)
	) $charset_collate;
	CREATE TABLE $table_name2 (
		id bigint(20) NOT NULL AUTO_INCREMENT,
		nombre tinytext NOT NULL,
		interpretes tinytext NOT NULL,
		year int(4) NOT NULL,
	    genero tinytext NOT NULL,
		tiempo_subido datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		tiempo_editado datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		descripcion longtext,
		fav int(2) NOT NULL,
		id_imgs longtext,
		UNIQUE KEY id (id)
	) $charset_collate;";
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}

// Agrego menu de panel de config en el Admin de Wordpress
add_action('admin_menu', 'ik_woomusicadb_menu');
function ik_woomusicadb_menu(){
    add_menu_page('Base de M&uacute;sica', 'Base de M&uacute;sica', 'manage_options', 'ik_woomusicadb_canciones', 'ik_woomusicadb_canciones', IK_WOOMUSICADB_PLUGIN_PUBLIC.'/img/woo-musicdb.png' );
    add_submenu_page('ik_woomusicadb_canciones', 'Base de M&uacute;sica - Administrar canciones', 'Canciones', 'manage_options', 'ik_woomusicadb_canciones', 'ik_woomusicadb_canciones' );
    add_submenu_page('ik_woomusicadb_canciones', 'Base de M&uacute;sica - Subir en masa Dinámica', 'Subir en masa Dinámica', 'manage_options', 'ik_woomusicadb_subir_masivo', 'ik_woomusicadb_subir_masivo' );
    add_submenu_page('ik_woomusicadb_canciones', 'Base de M&uacute;sica - Subir en masa convencional', 'Subir en masa convencional', 'manage_options', 'ik_woomusicadb_subir_masivo_submit', 'ik_woomusicadb_subir_masivo_submit' );
    add_submenu_page('ik_woomusicadb_canciones', 'Base de M&uacute;sica - Configuraci&oacute;n', 'Configuraci&oacute;n', 'manage_options', 'ik_woomusicadb_config', 'ik_woomusicadb_config' );
}

// Creo la página del panel de admin de canciones
function ik_woomusicadb_canciones(){
   include(IK_WOOMUSICADB_PLUGIN_DIR.'/templates/admin_canciones.php');
}

// Creo la página del panel para subir ajax
function ik_woomusicadb_subir_masivo(){
   include(IK_WOOMUSICADB_PLUGIN_DIR.'/templates/subidor_zip.php');
}

// Creo la página del panel para subir convencional
function ik_woomusicadb_subir_masivo_submit(){
    include(IK_WOOMUSICADB_PLUGIN_DIR.'/templates/subidor_zip_submit.php');
 }

// Creo la página del panel para config general
function ik_woomusicadb_config(){
    include(IK_WOOMUSICADB_PLUGIN_DIR.'/templates/config_panel.php');
}

//Permito subir archivos mp3
function ik_woomusicadb_myme_types($mime_types){
    $mime_types['m4a'] = 'audio/m4a';
    $mime_types['wav'] = 'audio/wav, audio/x-wav';
    $mime_types['mp3'] = 'audio/mpeg3, audio/x-mpeg-3';
	return $mime_types;
}
add_filter('upload_mimes', 'ik_woomusicadb_myme_types', 1, 1);

//Redirecciona al login si el usuario y el modo privado no se encuentran habilitados
function ik_woomusicadb_redirect_login() {
    if (ik_woomusicdb_datainfo('privado') == true){
        if (!is_user_logged_in() && $GLOBALS['pagenow'] !== 'wp-login.php'){
	        wp_redirect( get_site_url().'/wp-admin/' );
        }
    }
}
add_action( 'wp', 'ik_woomusicadb_redirect_login' );

//Activo el los JS y CSS del backend
add_action( 'admin_enqueue_scripts', 'ik_woomusicadb_backend_script_css' );
function ik_woomusicadb_backend_script_css(){
    wp_enqueue_style( 'ik_music_DB_CSS', IK_WOOMUSICADB_PLUGIN_PUBLIC.'css/style-backend.css', false, '1.3.1', 'all' );
    wp_enqueue_script( 'ik_music_DB_JS', IK_WOOMUSICADB_PLUGIN_PUBLIC.'js/ik_musica_db_scripts.js', array('jquery'), '3.2.11' );
    wp_localize_script( 'ik_music_DB_JS', 'ik_musicdb_ajaxurl', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
}

add_action( 'wp_ajax_my_action', 'my_action_callback' );
add_action( 'wp_ajax_nopriv_my_action', 'my_action_callback' );

function my_action_callback() {
    // Verificar nonce (opcional)
    if ( ! check_ajax_referer( 'my_nonce', 'security' ) ) {
        wp_send_json_error( 'Nonce no válido', 403 );
    }
    
    // Asegurarse de detener la ejecución después de enviar la respuesta JSON
    wp_die();
}
?>