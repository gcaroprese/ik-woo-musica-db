<?php

/*
Template: IK Woo Musica
Author: Gabriel Caroprese / Inforket.com
Update Date: 14/06/2021
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/* 
    Function para devolver valores de config
    de la base de datos
*/
function ik_woomusicdb_datainfo($dato_configinfo){
    global $wpdb;
    $dato_configinfo = sanitize_text_field($dato_configinfo);
    $woomusicadb_infovals_q = get_option('ik_musicadb_info');

    if ($woomusicadb_infovals_q != NULL){
        if (isset($woomusicadb_infovals_q[$dato_configinfo])){
            $dato_info_woomusicadb = $woomusicadb_infovals_q[$dato_configinfo];
        } else {
            $dato_info_woomusicadb = "";
        }
    } else if ($dato_configinfo == 'fotoalbumdefecto'){
        $dato_info_woomusicadb = IK_WOOMUSICADB_ALBUM_DEFECTO;
    } else if ($dato_configinfo == 'demominutos'){
        $dato_info_woomusicadb = IK_WOOMUSICADB_DEMO_MINUTOS_DEFECTO;
    } else if ($dato_configinfo == 'preciopista'){
        $dato_info_woomusicadb = IK_WOOMUSICADB_PRECIO_CANCIONES_DEFECTO;
    } else if ($dato_configinfo == 'genero'){
        $dato_info_woomusicadb = IK_WOOMUSICADB_GENERO_DEFECTO;
    } else if ($dato_configinfo == 'privado'){
        $dato_info_woomusicadb = false;
    } else {
        $dato_info_woomusicadb = "";
    }
    return $dato_info_woomusicadb;
}

//Funcion para devolver imagenes de albums depende la ocasion
function ik_woomusicadb_get_imagenes_album($img_ids, $uso = 'listado'){
	//Valor por defecto
	$album_foto = '';
	
	//
	if ($img_ids != NULL || $img_ids != ''){
	
		//unserializo el dato y me aseguro que es array para mostrarla galeria
		$album_fotos_array = maybe_unserialize($img_ids);
		
		if (is_array($album_fotos_array)){
		
			if ($uso == 'galeria'){
				
				foreach($album_fotos_array as $key => $id_foto){

					//La primera imagen es la activa en la galeria
					if ($key == 0){
						$clase = 'album_foto_activa ik_musicadb_overlay img_galeria_album_'.$key;
					} else {
						$clase = 'album_foto_inactiva ik_musicadb_overlay img_galeria_album_'.$key;								
					}
					
					
					$imagen = wp_get_attachment_image( $id_foto, 'full', false, array('class'=>$clase));
					
					if ($imagen != ''){
						//Marco las keys de las imagenes validas
						$keyimagenes[] = $key;
						
						//Agrego la imagen a la galeria
						$album_foto .= $imagen;
					}
				
				}	
				
				if (isset($keyimagenes)){
					$album_foto .= '<ul class="seleccion_img_galeria_album">';
					foreach ($keyimagenes as $keyimagen){
						$album_foto .= '<li class="ik_musicadb_mostrar_img_galeria" seleccion_foto="img_galeria_album_'.$keyimagen.'"><span class="dashicons dashicons-marker"></span></li>';
					}
					$album_foto .= '</ul>';						
				}
					
			} else if ($uso == 'tienda'){
				foreach($album_fotos_array as $key => $id_foto){

					//La primera imagen es la activa en la galeria
					if ($key == 0){
						$clase = 'album_foto_activa img_galeria_album_'.$key;
					} else {
						$clase = 'album_foto_inactiva img_galeria_album_'.$key;								
					}
					
					
					$imagen = wp_get_attachment_image( $id_foto, 'thumbnail', false, array('class'=>$clase));
					
					if ($imagen != ''){
						//Marco las keys de las imagenes validas
						$keyimagenes[] = $key;
						
						//Agrego la imagen a la galeria
						$album_foto .= $imagen;
					}
					if (isset($keyimagenes)){
						$album_foto .= '<ul class="seleccion_img_galeria_album">';
						foreach ($keyimagenes as $keyimagen){
							$album_foto .= '<li class="ik_musicadb_mostrar_img_galeria" seleccion_foto="img_galeria_album_'.$keyimagen.'"><span class="dashicons dashicons-marker"></span></li>';
						}
						$album_foto .= '</ul>';						
					}
					
				
				}				
				
			} else if ($uso == 'wpmedia'){
				//galeria multimedia
				$var_img_ids = '';
				foreach($album_fotos_array as $id_foto){
					if (is_int($id_foto)){
						$var_img_ids .= ','.$id_foto.',';
					}
				}
				
				if ($var_img_ids != ''){
					$var_img_ids = substr($var_img_ids, 0, -1);
					$album_foto = $var_img_ids;
				}

			} else {
				//Listado
				$foto = wp_get_attachment_image( $album_fotos_array[0], array('155', '155'), "", array( "class" => "img-responsive" ) );
				
				if ($foto != ''){
					$album_foto = $foto;
				}
			}
		}
	}
	
	//Si las fotos eran invalidas o no hay asociadas
	if ($album_foto == '' && $uso == 'wpmedia'){
		$album_foto = 'no';
	} else if ($album_foto == '' && $uso != 'wpmedia'){
		$album_foto = '<img src="'.IK_WOOMUSICADB_ALBUM_DEFECTO.'" alt="fotos de portada album" />';		
	}
	
	return $album_foto;
}


//funcion para subir mp3
function ik_woomusicadb_media_subir_mp3( $file, $post_id = 0, $desc = null, $return = 'html' ) {
    if ( ! empty( $file ) ) {
        
        /**
         * 
         * Adaptacion de la funcion media_sideload_image para permitir mp3
         * 
         */
 
        $allowed_extensions = array( 'mp3' );
         
        $allowed_extensions = apply_filters( 'image_sideload_extensions', $allowed_extensions, $file );
        $allowed_extensions = array_map( 'preg_quote', $allowed_extensions );
 
        // Set variables for storage, fix file filename for query strings.
        preg_match( '/[^\?]+\.(' . implode( '|', $allowed_extensions ) . ')\b/i', $file, $matches );
 
        if ( ! $matches ) {
            return new WP_Error( 'image_sideload_failed', __( 'Invalid image URL.' ) );
        }
 
        $file_array         = array();
        $file_array['name'] = wp_basename( $matches[0] );
 
        // Download file to temp location.
        $file_array['tmp_name'] = download_url( $file );
 
        // If error storing temporarily, return the error.
        if ( is_wp_error( $file_array['tmp_name'] ) ) {
            return $file_array['tmp_name'];
        }
 
        // Do the validation and storage stuff.
        $id = media_handle_sideload( $file_array, $post_id, $desc );
 
        // If error storing permanently, unlink.
        if ( is_wp_error( $id ) ) {
            @unlink( $file_array['tmp_name'] );
            return $id;
        }
 
        // Store the original attachment source in meta.
        add_post_meta( $id, '_source_url', $file );
 
        // If attachment ID was requested, return it.
        if ( 'id' === $return ) {
            return $id;
        }
 
    }
    
    return;

}

//Agregar canciones a album
function ik_woomusicadb_agregar_canciones_album($id_files, $id_album){
    $canciones_agregadas = 0;
    $id_album = sanitize_text_field($id_album);
    
    foreach ( $id_files as $id_file){
        $id_file = absint($id_file);
        if ($id_file > 0){
            //Creo el array de los meta datos del mp3
            $url_audio = wp_upload_dir()['baseurl'].'/'.get_post_meta( $id_file, '_wp_attached_file', true);
            
            //Leo los meta datos del archivo de audio
            $meta_tags_audio = get_post_meta($id_file, '_wp_attachment_metadata', true);

            // si algun valor es valido
            if (isset($meta_tags_audio['length']) || isset($meta_tags_audio['title']) || isset($meta_tags_audio['track_number'])){
                if (isset($meta_tags_audio['title'])){
                    $titulo = $meta_tags_audio['title'];
                } else {
                    $titulo = 'Sin Nombre';
                }
              
                if (isset($meta_tags_audio['artist'])){
                    $interpretes = $meta_tags_audio['artist'];
                } else {
                    $interpretes = 'Sin Nombre';
                }
                
                if (isset($meta_tags_audio['band'])){
                    $banda = $meta_tags_audio['band'];
                } else {
                    $banda = 'Sin Nombre';
                }
                
                if (isset($meta_tags_audio['album'])){
                    $album = $meta_tags_audio['album'];
                } else {
                    $album = 'Sin Nombre';
                }
                
                if (isset($meta_tags_audio['year'])){
                    $year = $meta_tags_audio['year'];
                } else {
                    $year = 'N/A';
                }
                
                $genero = ik_woomusicdb_datainfo('genero');
                if (isset($meta_tags_audio['genre'])){
                    if ($meta_tags_audio['genre'] != ''){
                        $genero = $meta_tags_audio['genre'];
                    }
                }
                
                if (isset($meta_tags_audio['track_number'])){
                    $track_n = $meta_tags_audio['track_number'];
                } else {
                    $track_n = 0;
                }
                
                if (isset($meta_tags_audio['length_formatted'])){
                    $duracion = $meta_tags_audio['length_formatted'];
                } else {
                    $duracion = 'N/A';
                }
                
                if (isset($meta_tags_audio['length'])){
                    $duracion_segundos = $meta_tags_audio['length'];
                } else {
                    $duracion_segundos = 'N/A';
                }
                
                if (isset($meta_tags_audio['description'])){
                    $descripcion = $meta_tags_audio['description'];
                } else {
                    $descripcion = '';
                }
          
                // Creo cancion
                $canciones_datos  = array (
                        'titulo'=>$titulo,	
                        'interpretes'=>$interpretes,
                        'band'=>$banda,
                        'attachment_id'=>$id_file,	
                        'album_id'=>$id_album,	
                        'album'=>$album,	
                        'year'=>$year,
                        'numero_pista'=>$track_n,	
                        'genero'=>$genero,	
                        'duracion_segundos'=>$duracion_segundos,	
                        'duracion'=>$duracion,	
                        'descripcion'=>$descripcion,
                        'url_audio'=>$url_audio,
                );
                
                $cancionData = new Ik_MusicaDB_Canciones();
                $cancion_id = $cancionData->crear_cancion($canciones_datos);
                
                if ($cancion_id != 0){
                    $canciones_agregadas = $canciones_agregadas + 1;
                }
            }
            
        }
    }
    
    return $canciones_agregadas;
}

//devolver paginado de listados de musica
function ik_woomusicadb_get_paginado($url, $listing_total, $qty=20, $classcss = 'ik_musicadb_paginado'){
    
    // Veo el paginado
    $page = 1;
    if (isset($_GET["pagina"])){
        // I check if value is integer to avoid errors
        if (strval($_GET["pagina"]) == strval(intval($_GET["pagina"])) && $_GET["pagina"] > 0){
            $page = intval($_GET["pagina"]);
        }
    }
    
    $url = esc_url($url);
    $classcss = sanitize_text_field($classcss);
    $qty = absint($qty);
    $listing_total = absint($listing_total);

	if ($page > 0){
		$total_pages = intval($listing_total / $qty);
		
        if ($listing_total > $qty && $page <= $total_pages){
            $paginado = '<div class="'.$classcss.'">';
            
            //If there are a lot of pages
            if ($total_pages > 11){
                $almostlastpage1 = $total_pages - 1;
                $almostlastpage2 = $total_pages - 2;
                $halfpages1 = intval($total_pages/2);
                $halfpages2 = intval($total_pages/2)-1;
                
                $listing_limit = array('1', '2', $page, $halfpages2, $halfpages1, $almostlastpage2, $almostlastpage1, $total_pages);
                
                $pages_limited = true;
            } else{
                $listing_limit[0] = false;
                $pages_limited = false;
            }
            $arrowprevious = $page - 1;
            $arrownext = $page + 1;
            if ($arrowprevious > 1){
                $paginado.= '<a href="'.$url_licensesadmin_unlisted.'&listing='.$arrowprevious.'"><</a>';
            }
            for ($i = 1; $i <= $total_pages; $i++) {
                $showpage = true;
                
                if ($pages_limited == true && !in_array($i, $listing_limit)){
                    $nextpage = $page+1;
                    $beforepage = $page - 1;
                    if ($page != $i && $nextpage != $i && $beforepage != $i){
                        $showpage = false;
                    }
                }
                
                if ($showpage == true){
                    if ($page == $i){
                        $selectedPageN = 'class="actual_page"';
                    } else {
                        $selectedPageN = "";
                    }
                    
                    $paginado.= '<a '.$selectedPageN.' href="'.$url.'&pagina='.$i.'">'.$i.'</a>';
                    
                }
                
            }
            if ($arrownext < $total_pages){
                $paginado.= '<a href="'.$url.'&pagina='.$arrownext.'">></a>';
            }
            $paginado.= '</div>';
            
            return $paginado;
    	}
	}
    
}

//Chequeo si recaptcha se encuentra habilitado y lo carga en formulario
function ik_woomusicadb_get_recaptcha(){

    $recaptcha = '';
        
    $recapchacheckUse = get_option('ik_woomusicadb_recaptcha_use');
    

    $recapchaEnabled = (intval($recapchacheckUse) == 1) ? true : false;
    
    if ($recapchaEnabled){

        $recaptchakey = get_option('ik_woomusicadb_recaptcha_k');
        $recaptchasecret = get_option('ik_woomusicadb_recaptcha_s');
        
        if ($recaptchakey == false || $recaptchakey == NULL || $recaptchasecret == false || $recaptchasecret == NULL){
            //missing keys
            return;
        } 
        
        $recaptcha = '
        <input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response">
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
            <div class="g-recaptcha"
                  data-sitekey="'.$recaptchakey.'"
                  data-size="invisible">
            </div>
        <script>
        jQuery(document).ready(function($) {
            function onSubmit(token) {
                // habilita el botón de envío
                document.getElementById("submit-btn").disabled = false;
                // envía el formulario
                document.getElementById("music_form_search").submit();
            }
            
            document.querySelector("#music_form_search").addEventListener("submit", function(e) {
                e.preventDefault();
                grecaptcha.execute();
                var interval = setInterval(function() {
                var response = grecaptcha.getResponse();
                if (response.length > 0) {
                    clearInterval(interval);
                    document.getElementById("music_form_search").submit();
                }
                }, 500);
            });
        });
        </script>';
    }
    
    return $recaptcha;
}

/*
Cronjobs para eliminar cache de carrito y productos creados hace más de 3 días
*/

// Agregar acción al hook 'wp_loaded'
add_action('wp_loaded', 'my_cronjob_schedule');

// Función que programa el cronjob
function my_cronjob_schedule() {
    // Programar la tarea para que se ejecute cada 3 días
    if ( !wp_next_scheduled( 'my_cronjob' ) ) {
        wp_schedule_event( time(), 'three_days', 'my_cronjob' );
    }
}

// Agregar acción al hook 'my_cronjob'
add_action('my_cronjob', 'my_cronjob_task');

// Función que ejecuta la tarea del cronjob
function my_cronjob_task() {
    // Borrar carritos inactivos
    wc_delete_expired_transients();

    // Obtener productos privados que tengan el post_meta "woo_musicdb" y hayan sido creados hace más de 3 días
    $args = array(
        'post_type'      => 'product',
        'meta_key'       => 'woo_musicdb',
        'meta_value'     => 'yes',
        'meta_compare'   => '=',
        'date_query'     => array(
            'before'     => '3 days ago',
        ),
        'post_status'    => 'private',
        'posts_per_page' => -1,
    );
    $posts = get_posts( $args );

    // Recorrer los productos y borrar los que cumplan con los criterios
    foreach ( $posts as $post ) {
        wp_delete_post( $post->ID, true );
    }
    
    //limpio archivos mp3 temporales
    $upload_dir = wp_upload_dir();
    $temp_folder_path = $upload_dir['basedir'] . '/music_audio_temp/';
    
    $files = glob($temp_folder_path . '*');
    $three_days_ago = time() - (3 * 24 * 60 * 60);
    foreach ($files as $file) {
        if (is_file("$dir/$file") && $file != 'index.php' && time() - filemtime("$dir/$file") >= 259200) {
            unlink("$dir/$file");
        }
    }
    
}

// Definir la frecuencia 'three_days'
add_filter( 'cron_schedules', 'my_cronjob_interval' );
function my_cronjob_interval( $schedules ) {
    $schedules['three_days'] = array(
        'interval' => 259200, // 3 días en segundos
        'display'  => __( 'Cada 3 días' ),
    );
    return $schedules;
}

//funcion para subir zip de album
function ik_woomusicadb_subir_zip_album() {
    if (isset($_FILES['file']) && current_user_can( 'administrator' )){
        
        //Formatos de archivo aceptados
        $archivos_soportados = array('application/zip', 'application/x-zip-compressed');
    
        $nombre_archivo = $_FILES['file']['name'];
        $extension_archivo = pathinfo($nombre_archivo, PATHINFO_EXTENSION);

        if (in_array($_FILES['file']['type'], $archivos_soportados) || ($_FILES['file']['type'] == null && $extension_archivo == 'zip')) {
            $file_size = $_FILES['file']['size'];

            $file = $_FILES['file'];
            $upload_dir=wp_upload_dir();
            $target_dir = "/".IK_WOOMUSICADB_ARCHIVOS_TEMP."/";

            $upload_file_name = preg_replace('/\s+/', '', basename($_FILES["file"]["name"]));
            
            // Evito nombres repetidos
            $filecode = substr(md5(uniqid(rand(), true)), 4, 4); // 4 caracteres
            $filenowDate = date("Y/m/d");
            $filenumberedDate = strtotime($filenowDate);
            $filecodigoInv = strtoupper($filecode.$filenumberedDate);
            
            $file_name = rand().$filecodigoInv. sanitize_file_name($upload_file_name);
            $target_file = $target_dir . $file_name;
            $target_endfile = $upload_dir['basedir']. $target_file;
            move_uploaded_file($_FILES['file']['tmp_name'], $target_endfile);
            $public_photoid_url['name'] = sanitize_text_field($_FILES["file"]["name"]);
            $public_photoid_url['url'] = get_site_url().'/wp-content/uploads'.$target_file;
            $public_photoid_url['fileroot'] = $target_endfile;
            $public_photoid_url['file_name'] = $file_name;

            $output = $public_photoid_url;

        } else{
            if (isset($_FILES['file']['name'])){
                $nombre_archivo = sanitize_file_name($_FILES['file']['name']).'" ';
            } else {
                $nombre_archivo = '';
            }
            $output = 'Archivo '.$nombre_archivo.'no soportado.';
        }
    } else {
        $output = 'Error';
    }

    return $output;  
}

//funcion para procesar zip de album
function ik_woomusicadb_crear_album_zip($file_name, $album_dir, $zip_name) {
    if (current_user_can( 'administrator' )){
        
        $zip_name = sanitize_file_name($zip_name);
        $file_name = sanitize_file_name($file_name);
        $upload_dir = wp_upload_dir();
        $rutazip = $upload_dir['basedir']."/".IK_WOOMUSICADB_ARCHIVOS_TEMP."/";
        $rutazipfile = $upload_dir['basedir']."/".IK_WOOMUSICADB_ARCHIVOS_TEMP."/".$file_name;
        $name_without_extension = str_replace('.zip', '', $file_name);
        $carpetaTemporal = $rutazip.$name_without_extension;
        if (! is_dir($carpetaTemporal)) {
            mkdir($carpetaTemporal, 0755);
        }

        require_once(ABSPATH .'/wp-admin/includes/file.php');
        global $wp_filesystem;
        WP_Filesystem();
        
        $album_unzip = unzip_file($rutazipfile, $carpetaTemporal);
        
        if ($album_unzip){
            
            $directiorio = scandir($carpetaTemporal);
            
            $entrarAcarpeta = true;
            if (is_array($directiorio)){
                
                //busco el contenido del archivo descomprimido que puede ser una carpeta o archivos
                foreach ($directiorio as $contenido){
                    if (strpos($contenido, '.mp3') !== false  || strpos($contenido, '.jpg') !== false  || 
                    strpos($contenido, '.jpeg') !== false  || strpos($contenido, '.JPG') !== false  || strpos($contenido, '.JPEG') !== false){
                        $entrarAcarpeta == false;
                    } else {
                        $nombreCarpeta = $contenido;
                    }
                }
                
                if (!isset($nombreCarpeta)){
                    $nombreCarpeta = $name_without_extension;
                }
                
                /**
                 * Si entrar a carpeta es false, eso significa que todos 
                 * los archivos estan sueltos en la carpeta base
                 */
                if ($entrarAcarpeta == false){
                    $directorio_album = $carpetaTemporal;
                    $album_nombre = $zip_name;
                } else {
                    $directorio_album = $carpetaTemporal.'/'.$nombreCarpeta;
                    $album_nombre = $nombreCarpeta;
                }
                
                
                $album_nombre = sanitize_text_field($album_nombre);
                
                $albumsData = new Ik_MusicaDB_Albums();
                $album_id = $albumsData->crear_album($album_nombre);

                if ($album_id !== 0){
                    
                    $archivosAlbum = scandir($directorio_album);


                    // Cargo mp3 e img del disco
                    if (is_array($archivosAlbum)){
                        
                        //busco el contenido del archivo descomprimido que puede ser una carpeta o archivos
                        
                        $carpetaUploads = wp_upload_dir();
                        $url_directorio = $carpetaUploads['baseurl'].'/'.IK_WOOMUSICADB_ARCHIVOS_TEMP.'/'.$name_without_extension.'/'.$album_nombre.'/';


                        foreach ($archivosAlbum as $archivo){
                            
                            $url_archivo = $url_directorio.$archivo;
                            
                            if (strpos($archivo, '.mp3') !== false){

                                //subo el mp3 y lo agrego a un array de ID
                                $mp3_id = ik_woomusicadb_media_subir_mp3( $url_archivo, 0, null, 'id' );
                                
                                if (is_int($mp3_id)){
                                    $ids_mp3[] = $mp3_id;
                                }
                                
                            } else if (strpos($archivo, '.jpg') !== false  || 
                                strpos($archivo, '.jpeg') !== false  || 
                                strpos($archivo, '.JPG') !== false  || 
                                strpos($archivo, '.JPEG') !== false){
                                    
                                    
                                //Elimino info del archivo para liberar espacio y no tener problemas
                                if(extension_loaded('imagick')) {
                                    $image_loc = $directorio_album.'/'.$archivo;
                                    $img = new Imagick($image_loc);
                                    $img->stripImage();
                                    $img->writeImage($image_loc);
                                    $img->clear();
                                    $img->destroy();
                                }    
                                    
                                    
                                $img_id = media_sideload_image( $url_archivo, 0, null, 'id' );
                                
                                if (is_int($img_id)){
                                    
                                    //poner front.jpg al principio o simplemente agregar id de img al array
                                    if ((strpos($archivo, 'Front') !== false || 
                                    strpos($archivo, 'front') !== false || 
                                    strpos($archivo, 'FRONT') !== false) && 
                                    strpos($archivo, 'full') === false && 
                                    strpos($archivo, 'Full') === false && 
                                    isset($ids_img)){
                                        array_unshift($ids_img, $img_id);
                                    } else {
                                        $ids_img[] = $img_id;
                                    }
                                    
                                }
                                
                            }
                        }
                        
                        
                        if (isset($ids_img)){
                            //Asigno imgs al album
                            $albumsData = new Ik_MusicaDB_Albums();
                            $imagenes_agregadas = $albumsData->agregar_imagenes_album($album_id, $ids_img);
                        }                        
                        
                        if (isset($ids_mp3)){
                            //Asigno canciones al album
                            $canciones_agregadas = ik_woomusicadb_agregar_canciones_album($ids_mp3, $album_id);
                        } else {
                            $canciones_agregadas = 0;
                        }
        
                        if ($canciones_agregadas != 0 ){
                            $unzip_result['mensaje'] = '&Aacute;lbum #'.$album_id.' creado exitosamente.';  
                        } else {
                            $unzip_result['mensaje'] = '&Aacute;lbum #'.$album_id.' creado, pero no se encontraron canciones.';  
                        }
                        
                    } else {
                        $unzip_result['mensaje'] = '&Aacute;lbum #'.$album_id.' creado aunque la carpeta no contiene archivos.';  
                    }
                    
                    $unzip_result['result'] = 'ok';
                    
                } else {
                                                
                    $unzip_result['result'] = 'error';
                    $unzip_result['mensaje'] = 'El &Aacute;lbum "'.$album_nombre.'" no pudo ser creado.';  
                }
        
            } else {
            
                $unzip_result['result'] = 'error';
                $unzip_result['mensaje'] = 'Archivos no encontrados en "'.$file_name.'"';  
            
            }
            
            //Elimino el archivo zip y la carpeta luego de descomprimir
            if (is_file($rutazipfile)) {
                unlink($rutazipfile);
            } 
            
            if (isset($archivosAlbum)){
                foreach ($archivosAlbum as $archivo){
                    if (is_file($directorio_album.'/'.$archivo)) {
                        unlink($directorio_album.'/'.$archivo);
                    }
                }
                rmdir($directorio_album.'/');
            }
            if (is_dir($carpetaTemporal.'/')) {
                if (is_dir($carpetaTemporal.'/')){
                    rmdir($carpetaTemporal.'/');
                }
            }
         
        } else{
            $unzip_result['result'] = 'error';
            $unzip_result['mensaje'] = 'No se pudo descomprimir el archivo "'.$file_name.'"';
        }
        
    } else {
        $unzip_result['mensaje'] = 'Error';
    }

    return $unzip_result;    
}

?>