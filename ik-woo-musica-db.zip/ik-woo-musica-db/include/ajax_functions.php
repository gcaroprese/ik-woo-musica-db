<?php

/*
Ajax Functions
Author: Gabriel Caroprese / Inforket.com
Update Date: 14/06/2021
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

// Ajax para album por defecto subido
add_action( 'wp_ajax_ik_woomusicadb_albumimg_mediasubir', 'ik_woomusicadb_albumimg_mediasubir'   );
function ik_woomusicadb_albumimg_mediasubir() {
    if(isset($_GET['img_id']) && current_user_can( 'administrator' )){
        $id_file = intval($_GET['img_id']);
        if ($id_file != 0){
            $src_file = wp_upload_dir()['baseurl'].'/'.get_post_meta( $id_file, '_wp_attached_file', true);
            wp_send_json_success( $src_file );
        } else {
            wp_send_json_success( false );
        }
    } else {
        wp_send_json_success( false );    
    }
    wp_die();     
}

// Ajax para subir archivos de audio
add_action( 'wp_ajax_ik_woomusicadb_album_mp3_subir', 'ik_woomusicadb_album_mp3_subir');
function ik_woomusicadb_album_mp3_subir() {
    if(isset($_GET['mp3_id']) && isset($_GET['id_de_album']) && current_user_can( 'administrator' )){
        $id_files = explode(",", $_GET['mp3_id']);
        $id_album = intval($_GET['id_de_album']);
        
        $canciones_agregadas = ik_woomusicadb_agregar_canciones_album( $id_files, $id_album);
            
        if ($canciones_agregadas != 0 ){               
            wp_send_json_success( false );
        } else {
            wp_send_json_success( true );
        }
                
    } else {
        wp_send_json_success( false );    
    }
    wp_die();     
}


// Ajax crear nuevo album
add_action( 'wp_ajax_ik_woomusicadb_crear_album_subir', 'ik_woomusicadb_crear_album_subir'   );
function ik_woomusicadb_crear_album_subir() {
    if(isset($_POST['album_nombre']) && current_user_can( 'administrator' )){
        $album_nombre = sanitize_text_field($_POST['album_nombre']);
        
        $albumsData = new Ik_MusicaDB_Albums();
        $album_id = absint($albumsData->crear_album($album_nombre));
    
        echo json_encode( $album_id );

    }
    
    wp_die();     
}


//Ajax para buscar un album por nombre para subir canciones
add_action( 'wp_ajax_ik_woomusicadb_buscar_album_subir', 'ik_woomusicadb_buscar_album_subir');
function ik_woomusicadb_buscar_album_subir(){
    //por si no se encuentra nada
    $results = '';
    
    if(isset($_POST['text_album_input']) && current_user_can( 'administrator' )){
        $search_input = sanitize_text_field($_POST['text_album_input']);

        $albumsData = new Ik_MusicaDB_Albums();
        $results = $albumsData->buscar_albums_listar($search_input);
        
        echo json_encode( $results );
        
    } else {
        echo json_encode( $results );
    }
    wp_die();         
}

//Ajax para mostrar info sobre un album seleccionado
add_action( 'wp_ajax_ik_woomusicadb_ajax_ver_album_info', 'ik_woomusicadb_ajax_ver_album_info');
function ik_woomusicadb_ajax_ver_album_info(){
    //por si no se encuentra nada
    $results = false;
    $infoAlbums = '';
    
    if(isset($_POST['album_id']) && current_user_can( 'administrator' )){
        $album_id = intval($_POST['album_id']);

        $albumsData = new Ik_MusicaDB_Albums();
        $album = $albumsData->get_album_by_id($album_id);
        
        //Verifico si el album existe
        if ($album !== false){

            $cancionData = new Ik_MusicaDB_Canciones();
            $canciones = $cancionData->get_canciones_album($album->id);

			$album_foto = ik_woomusicadb_get_imagenes_album($album->id_imgs, 'galeria');
					
            if ($album->descripcion != NULL || $album->descripcion != ''){
                $descripcion = $album->descripcion;
            } else {
                $descripcion = '<span class="ik_musicadb_dato_vacio">Sin Informaci&oacute;n</span>';
            }
            $infoAlbums .= '            
                <div class="ik_music_db_popup_album_data" album_id="'.$album->id.'">
                <div class="ik_music_db_album_columna">
                    <div class="ik_woomusicadb_album_portada_detalles ik_musicadb_transition_hover">
                        '.$album_foto.'
                        <div id="ik_woomusicadb_editar_fotos_album" class="ik_musicadb_transition_hide">
                            <span class="dashicons dashicons-format-image"></span>
                        </div>
                    </div>
                    <div class="ik_woomusicadb_album_medio_detalles">
                        <div class="ik_musicadb_id_album ik_woomusicadb_datos_album">
                            <span><b>ID de &Aacute;lbum:</b> </span>
                            <span>#'.$album->id.'</span>
                        </div>
                        <div class="ik_musicadb_titulo_album ik_woomusicadb_datos_album ik_musicadb_transition_hover">
                            <span><b>T&iacute;tulo:</b> </span>
                            <span class="ik_musicadb_titulo_album_input ik_musica_db_campo_editar" dato_valor="'.$album->nombre.'">'.$album->nombre.'</span>
                            <div id="ik_musicadb_editar_titulo" class="ik_musicadb_transition_hide ik_musicadb_editar_campo">
                                <span class="dashicons dashicons-edit"></span>
                            </div>
                        </div>
                        <div class="ik_musicadb_interpretes_album ik_woomusicadb_datos_album ik_musicadb_transition_hover">
                            <span><b>Int&eacute;rpretes:</b> </span>
                            <span class="ik_musicadb_interpretes_album_input ik_musica_db_campo_editar" dato_valor="'.$album->interpretes.'">'.$album->interpretes.'</span>
                            <div id="ik_musicadb_editar_interpretes" class="ik_musicadb_transition_hide ik_musicadb_editar_campo">
                                <span class="dashicons dashicons-edit"></span>
                            </div>
                        </div>
                        <div class="ik_musicadb_year_album ik_woomusicadb_datos_album ik_musicadb_transition_hover">
                            <span><b>A&ntilde;o:</b> </span>
                            <span class="ik_musicadb_year_album_input ik_musica_db_campo_editar" dato_valor="'.$album->year.'">'.$album->year.'</span>
                            <div id="ik_musicadb_editar_year" class="ik_musicadb_transition_hide ik_musicadb_editar_campo">
                                <span class="dashicons dashicons-edit"></span>
                            </div>                            
                        </div>
                        <div class="ik_musicadb_genero_album ik_woomusicadb_datos_album ik_musicadb_transition_hover">
                            <span><b>G&eacute;nero:</b> </span>
                            <span class="ik_musicadb_genero_album_input ik_musica_db_campo_editar" dato_valor="'.$album->genero.'">'.$album->genero.'</span>
                            <div id="ik_musicadb_editar_genero" class="ik_musicadb_transition_hide ik_musicadb_editar_campo">
                                <span class="dashicons dashicons-edit"></span>
                            </div>                            
                        </div>
                        <div class="ik_musicadb_descripcion_album ik_woomusicadb_datos_album ik_musicadb_transition_hover">
                            <span><b>Descripci&oacute;n:</b></span><br />
                            <span class="ik_musicadb_descripcion_album_input ik_musica_db_campo_editar" dato_valor="'.$album->descripcion.'">'.$descripcion.'</span>
                            <div id="ik_musicadb_editar_descripcion" class="ik_musicadb_transition_hide ik_musicadb_editar_campo">
                                <span class="dashicons dashicons-edit"></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ik_music_db_album_columna" id="ik_music_db_album_columna_canciones">
                    <div class="ik_music_db_album_columna_canciones_inner">
                    '.$canciones.'
                    </div>    
                </div>
                <div class="ik_music_db_album_columna_completa">
    			    <input type="button" album_id="'.$album->id.'" class="button-primary ik_musicadb_cancelar" value="Eliminar Disco" id="ik_musicadb_eliminar_album">
                    <input type="button" class="button-primary" value="Guardar Cambios" id="ik_musicadb_guardar_cambios_album">
                </div>
            </div>';
        }
        
    }
    
    echo json_encode( $infoAlbums );
    wp_die();         
}

//Funcion para devolver URL de cancion para reproducir en admin
add_action( 'wp_ajax_ik_woomusicadb_ajax_reproducir_cancion', 'ik_woomusicadb_ajax_reproducir_cancion');
function ik_woomusicadb_ajax_reproducir_cancion(){
    //por si no se encuentra nada
    $datos_cancion = 'error';
    
    if(isset($_POST['cancion_id'])){
        $cancion_id = absint($_POST['cancion_id']);
		$cancionData = new Ik_MusicaDB_Canciones();
        $datos_cancion = $cancionData->get_url($cancion_id);
	}
	
    echo json_encode( $datos_cancion );
    wp_die(); 
}

//Eliminar album
add_action( 'wp_ajax_ik_woomusicadb_ajax_eliminar_album_info', 'ik_woomusicadb_ajax_eliminar_album_info');
function ik_woomusicadb_ajax_eliminar_album_info(){
    if(isset($_POST['album_id']) && current_user_can( 'administrator' )){
        $id_album = absint($_POST['album_id']);

        $cancionData = new Ik_MusicaDB_Canciones();
        $albumsData = new Ik_MusicaDB_Albums();
        $cancionData->eliminar_por_album_id($id_album);
        $albumsData->eliminar($id_album);

        echo json_encode( true );
    }
    wp_die();         
}

//Funcion para asociar img ID del album
add_action( 'wp_ajax_ik_woomusicadb_ajax_album_subir_imgs', 'ik_woomusicadb_ajax_album_subir_imgs');
function ik_woomusicadb_ajax_album_subir_imgs(){
    if(isset($_GET['album_id']) && isset($_GET['ids_imgs']) && current_user_can( 'administrator' )){
        $id_album = absint($_GET['album_id']);
        $id_imgs = explode(",", $_GET['ids_imgs']);
        
        $albumsData = new Ik_MusicaDB_Albums();
        $imagenes_agregadas = $albumsData->agregar_imagenes_album($id_album, $id_imgs);

        echo json_encode( $imagenes_agregadas );
    }
    wp_die();         
}


//Funcion para buscar IDs de imagenes asociadas a un album
add_action( 'wp_ajax_ik_woomusicadb_ajax_album_get_img_ids', 'ik_woomusicadb_ajax_album_get_img_ids');
function ik_woomusicadb_ajax_album_get_img_ids(){
	//Resultado por defecto
	$imagenes_album = 'no';
	
    if(isset($_GET['album_id']) && current_user_can( 'administrator' )){
        $id_album = absint($_GET['album_id']);
		
	    $albumsData = new Ik_MusicaDB_Albums();
        $id_imgs = $albumsData->get_imgs($id_album);
        
		if ($id_imgs !== false){
			$imagenes_album = ik_woomusicadb_get_imagenes_album($id_imgs, 'wpmedia');
		}
		
        echo json_encode( $imagenes_album );
    }
    wp_die();         
}

//Funcion para editar datos del album
add_action( 'wp_ajax_ik_woomusicadb_ajax_album_editar_datos', 'ik_woomusicadb_ajax_album_editar_datos');
function ik_woomusicadb_ajax_album_editar_datos(){

    if(isset($_POST['album_id']) && isset($_POST['dato_ingresado']) && isset($_POST['input_ingresado']) && current_user_can( 'administrator' )){
        $id_album = absint($_POST['album_id']);
        $dato_ingresado = sanitize_text_field($_POST['dato_ingresado']);
        $input_ingresado = sanitize_text_field($_POST['input_ingresado']);
		$input_ingresado = str_replace("\\", "", $input_ingresado);
		
        $albumsData = new Ik_MusicaDB_Albums();
        $resultado = $albumsData->actualizar_datos($id_album, $dato_ingresado, $input_ingresado);
                
        echo json_encode( $resultado );
    }
	
    wp_die();         
}


// Ajax para subir archivo zip
add_action( 'wp_ajax_ik_woomusicadb_subir_zip_album_ajax', 'ik_woomusicadb_subir_zip_album_ajax');
function ik_woomusicadb_subir_zip_album_ajax() {
    $data_zip = 'Error';
    if (isset($_POST['file_name']) && isset($_POST['album_dir']) && isset($_POST['zip_name'])){
        $data_zip = ik_woomusicadb_subir_zip_album($_POST['file_name'], $_POST['album_dir'], $_POST['zip_name']);
    }

    wp_send_json_success( $data_zip );    
    wp_die();     
}

// Ajax para descomprimir zip, crear album y asignar canciones
add_action( 'wp_ajax_ik_woomusicadb_crear_album_zip_ajax', 'ik_woomusicadb_crear_album_zip_ajax');
function ik_woomusicadb_crear_album_zip_ajax() {
    $unzip_result = ik_woomusicadb_crear_album_zip();
    echo json_encode( $unzip_result );

    wp_die();
}

//Funcion para editar nombres y numero de pista de canciones
add_action( 'wp_ajax_ik_woomusicadb_editar_cancion', 'ik_woomusicadb_editar_cancion');
function ik_woomusicadb_editar_cancion(){
    
    //valor por defecto
    $updated = false;

    if(isset($_POST['cancion_id']) && isset($_POST['ntrack']) && isset($_POST['nombre_cancion']) && current_user_can( 'administrator' )){
        $cancion_id = absint($_POST['cancion_id']);
        $ntrack = absint($_POST['ntrack']);
        $nombre_cancion = sanitize_text_field($_POST['nombre_cancion']);
        $nombre_cancion = str_replace('\\', '', $nombre_cancion);
        
        if ($cancion_id > 0){
    		
    		$cancionData = new Ik_MusicaDB_Canciones();
            $updated = $cancionData->editar_nombre_pista($cancion_id, $ntrack, $nombre_cancion);
        		
        }
    }
    
    echo json_encode( $updated );
    wp_die();         
}

//Eliminar cancion
add_action( 'wp_ajax_ik_woomusicadb_eliminar_cancion', 'ik_woomusicadb_eliminar_cancion');
function ik_woomusicadb_eliminar_cancion(){
    if(isset($_POST['cancion_id']) && isset($_POST['eliminarTodosLados']) && current_user_can( 'administrator' )){
        $cancion_id = absint($_POST['cancion_id']);
        $eliminarTodosLados = absint($_POST['eliminarTodosLados']);

        //si $eliminarTodosLados es 1 y hay que eliminar de todos lados
        if($eliminarTodosLados == 1){
            $cancionData = new Ik_MusicaDB_Canciones();
            $attachment_id = $cancionData->get_attachment_id_cancion($cancion_id);
            
            if ($attachment_id > 0){
                
                $cancionData = new Ik_MusicaDB_Canciones();
                $eliminadoDB = $cancionData->eliminar_por_attachment_id($attachment_id);
                
                //elimino el archivo
                wp_delete_attachment($attachment_id);
                    
            } else {
                $cancionData = new Ik_MusicaDB_Canciones();
                $resultadoEliminar = $cancionData->eliminar_cancion_por_id($cancion_id);
            }
            
        } else {
            $cancionData = new Ik_MusicaDB_Canciones();
            $resultadoEliminar = $cancionData->eliminar_cancion_por_id($cancion_id);
        }
        
        echo json_encode( true );
    }
    wp_die();         
}

//Funcion para agregar o quitar album de favoritos
add_action( 'wp_ajax_ik_woomusicadb_album_agregar_quitar_fav', 'ik_woomusicadb_album_agregar_quitar_fav');
function ik_woomusicadb_album_agregar_quitar_fav(){

    if(isset($_POST['album_id']) && current_user_can( 'administrator' )){
        $id_album = absint($_POST['album_id']);
        if (isset($_POST['valor_fav'])){
            $valor_fav = absint($_POST['valor_fav']);
        } else {
            $valor_fav = 1;            
        }
        
        if ($valor_fav !== 1){
            $valor_fav = 1;
            $result = true;
        } else {
            $valor_fav = 0;
            $result = false;
        }
		
	    $albumsData = new Ik_MusicaDB_Albums();
        $albumsData->agregar_favoritos($id_album, $valor_fav);
		
        echo json_encode( $result );
    }
	
    wp_die();         
}


//Funcion para reproducir segundos de un mp3
add_action('wp_ajax_nopriv_ik_woomusicadb_audio_url_segs', 'ik_woomusicadb_audio_url_segs');
add_action('wp_ajax_ik_woomusicadb_audio_url_segs', 'ik_woomusicadb_audio_url_segs');

function ik_woomusicadb_audio_url_segs() {
    $canciones_data = new Ik_MusicaDB_Canciones();
    $id = isset( $_POST['audio_id'] ) ? intval( $_POST['audio_id'] ) : 0;
    if ( $id < 1 ) {
        wp_send_json_error( 'Invalid ID' );
    }
    $cancion = $canciones_data->get_url( $id );

    $cancion_url = (isset($cancion['attachment_id'])) ? get_attached_file(absint($cancion['attachment_id'])) : false;

    if ( file_exists($cancion_url) && isset($cancion['url'])) {
        
        //Ver cantidad de segundos a reproducir
        $demosegundos = ik_woomusicdb_datainfo('demominutos');
        
        // Obtener información del archivo de audio    
        require_once(IK_WOOMUSICADB_PLUGIN_DIR . '/include/getid3/getid3.php');
        $getID3 = new getID3;
        $audio_file_info = $getID3->analyze($cancion_url);
        $audio_file_duration = $audio_file_info['playtime_seconds'];
        
        // Si la duración es menor o igual a 30 segundos, no hace falta recortar el archivo
        if ($audio_file_duration <= $demosegundos) {
            wp_send_json_success($cancion['url']);
        } else {    
            // Crear el nombre del archivo temporal
            $filename = uniqid() . '_' . date('YmdHis') . '_' . rand(100, 999) . '.mp3';
            // Crear el directorio para los archivos temporales si no existe
            $upload_dir = wp_upload_dir();
            $audio_temp_folder = $upload_dir['basedir'] . '/music_audio_temp';
            if (!file_exists($audio_temp_folder)) {
                mkdir($audio_temp_folder, 0755, true);
            }
            // Recortar el archivo de audio y guardarlo en un archivo temporal
            $audio_temp_path = $audio_temp_folder . '/' . $filename;
            $audio_temp_url = $upload_dir['baseurl'] . '/music_audio_temp/' . $filename;
            
            //segundos a cortar
            $segundos_demo = intval(ik_woomusicdb_datainfo('demominutos'));

            require_once(IK_WOOMUSICADB_PLUGIN_DIR . '/include/php-mp3/vendor/autoload.php');
            
            \falahati\PHPMP3\MpegAudio::fromFile($cancion['url'])->trim(0, $segundos_demo)->saveFile($audio_temp_path);

            wp_send_json_success($audio_temp_url);
            
        }
    } else {
        wp_send_json_error( $cancion_url );            
    }
    wp_die();         
}

add_action( 'wp_ajax_ik_woomusicadb_add_song_to_cart', 'ik_woomusicadb_add_song_to_cart' );
add_action( 'wp_ajax_nopriv_ik_woomusicadb_add_song_to_cart', 'ik_woomusicadb_add_song_to_cart' );
function ik_woomusicadb_add_song_to_cart() {
    // Aquí va el código que se ejecutará al llamar la función Ajax
    $data_id = isset( $_POST['audio_id'] ) ? absint( $_POST['audio_id'] ) : false;

    $albums_data = new Ik_MusicaDB_Albums();
    $song_data = new Ik_MusicaDB_Canciones();

    $cancion = $song_data->get_url($data_id);

    if($cancion != 'error'){
        //veo un admin para asociar producto
        $admins = get_users(array('role' => 'administrator', 'number' => 1));
        $user_admin_to_assoc = reset($admins); // obtiene el primer usuario de la lista
        $user_id_admin = ($user_admin_to_assoc) ? $user_admin_to_assoc->ID : 1;

        $nombre_pista = (isset($cancion['titulo'])) ? $cancion['titulo'] : 'mp3';
        $url_mp3 = $cancion['url'];
        $album_id = $cancion['album_id'];

        //data to set thumbnail
        $album_data = $albums_data->get_album_by_id($album_id);
        $tapa_id_img = (isset($album_data->id_imgs)) ? $album_data->id_imgs : false;
        if($tapa_id_img != false){
            $tapa_id_img = (is_serialized($album_data->id_imgs)) ? maybe_unserialize($album_data->id_imgs) : false;
            $tapa_id_img = (isset($tapa_id_img[0])) ? absint($tapa_id_img[0]) : false;
        }

        // Crear un producto en WooCommerce con la información proporcionada
        $post_title = __( 'Pista', 'ik-musicdb' ) .' '. $nombre_pista;
        $post_status = 'publish';
        $post_type = 'product';
        $post_content = '';
        $post_author = $user_id_admin;
    
        // Crear la publicación del producto
        $product_id = wp_insert_post(
            array(
                'post_title' => $post_title,
                'post_content' => $post_content,
                'post_date'=>date('Y-m-d H:i:s'), 
                'post_date_gmt'=> date('Y-m-d H:i:s'), 
                'post_status' => $post_status,
                'post_type' => $post_type,
                'post_author' => $post_author
            )
        );

        add_post_meta($product_id, '_stock_status', 'instock');
        add_post_meta($product_id, 'woo_musicdb', true);

        //set thumbnai
        if($tapa_id_img){
            add_post_meta($product_id, '_thumbnail_id', $tapa_id_img);
        }


        //Fijo el precio tomando los datos de configuracion
        $price = floatval(ik_woomusicdb_datainfo('preciopista'));
        add_post_meta($product_id, '_regular_price', $price);
        add_post_meta($product_id, '_price', $price);

        // Get an instance of the WC_Product object (from a defined product ID)
        $product = wc_get_product( $product_id ); // <=== Be sure it's the product ID

        $file_md5 = md5( $url_mp3 );
        $download = new WC_Product_Download();
        $download->set_name( $nombre_pista );
        $download->set_id( $file_md5 );
        $download->set_file( $url_mp3 );
        $downloads[$file_md5] = $download;
        $product->set_downloadable( true );
        $product->set_virtual( true );  
        $product->set_sold_individually( true );
        $product->set_downloads( $downloads );
        $product->set_catalog_visibility('hidden');
        //2 días para ser descargado
        $product->set_download_expiry(2);
        $product->save();

        // Agregar producto al carrito
        WC()->cart->add_to_cart($product_id);

        // Actualizar fragmento del carrito
        WC_AJAX::get_refreshed_fragments();
    }

    wp_die();
}



?>