<?php

/*
Shortcode: Albums Destacados [fav_music_albums]
Author: Gabriel Caroprese / Inforket.com
Update Date: 12/05/2023
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

//Form form_id
add_shortcode('fav_music_albums', 'ik_woomusicadb_shortcode_fav_music_albums');
function ik_woomusicadb_shortcode_fav_music_albums(){

    $albums = new Ik_MusicaDB_Albums();
    $fav_albums = '<style>
    .ik_music_db_fav_album_data {
        padding: 12px;
        border: 1px solid #5f0000;
        border-radius: 12px;
        margin-bottom: 20px;
    }
    .ik_music_db_fav_album_data .ik_woomusicadb_album_portada{
        padding: 14px;
        border: 1px solid #ccc;
        border-radius: 20px;
        display: grid;
        max-width: 150px;
    }
    .ik_music_db_fav_album_data .ik_woomusicadb_album_portada img{
        width: 150px;
        border-radius: 3px;
    }
    .ik_music_db_fav_album_data .ik_woomusicadb_album_medio_detalles{
        padding: 2px 10px;
    }
    .ik_music_db_fav_album_data ul.seleccion_img_galeria_album {
        padding-bottom: 0;
        list-style: none;
        display: none;
    }
    .ik_music_db_fav_album_data .ik_music_db_album_columna{
        display: flow-root;
        width: 100%;
        padding: 0 15px 20px;
    }
    .ik_music_db_fav_album_data .ik_music_db_album_columna ul{
        padding: 0;
        list-style: none;
    }
    @media(min-width: 980px){
        .ik_music_db_fav_album_data {
            float: left;
            width: 49%;
            margin-right: 1%;
        }
        .ik_music_db_fav_album_data .ik_woomusicadb_album_portada{
            float: left;
            max-width: 200px;
        }
        .ik_music_db_fav_album_data .ik_woomusicadb_album_medio_detalles{
            float: left;
            width: calc(100% - 200px);
        }
        .ik_music_db_fav_album_data .ik_music_db_album_columna ul {
            column-count: 2;
        }
        .ik_music_db_fav_album_data_row {
            display: flex;
        }
    }
    @media(max-width: 980px){
        .ik_music_db_fav_album_data .ik_woomusicadb_album_portada {
            margin-bottom: 10px;
        }
        .ik_music_db_fav_album_data .ik_music_db_album_columna{
            padding: 0 8px 20px;
        }  
        .ik_music_db_album_columna_canciones{
            padding: 20px! important
        }
    }
    </style>';

    $fav_albums .= $albums->get_fav_albums();

    return $fav_albums;

}