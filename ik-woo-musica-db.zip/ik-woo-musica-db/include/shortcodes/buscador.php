<?php

/*
Shortcode: Buscador Canciones [search_music][search_results_music]
Author: Gabriel Caroprese / Inforket.com
Update Date: 12/05/2023
*/

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

//Form form_id
add_shortcode('search_music', 'ik_woomusicadb_shortcode_buscador_musica');
function ik_woomusicadb_shortcode_buscador_musica(){

    //para los campos de fecha
    if ( ! wp_script_is( 'jquery-ui-datepicker', 'enqueued' )) {
        wp_enqueue_script( 'jquery-ui-datepicker' );
    }

    $searchall_value = '';
    $title_value = '';
    $genre_value = '';
    $fromyear_value = '';
    $toyear_value = '';
    $artist_value = '';
    $albumsearch_value = '';


    if (isset($_GET['searchall'])  || isset($_GET['title'])  || isset($_GET['genre'])  || isset($_GET['fromyear'])  || isset($_GET['toyear'])  || isset($_GET['artist'])  || isset($_GET['albumsearch'])){
        
        //check if I have to search customized or just search in general
        $keywordAll = (isset($_GET['searchall'])) ? sanitize_text_field($_GET['searchall']) : '';
        $searchGeneral = ($keywordAll != '' && $keywordAll != ' ') ? true : false;

        if($searchGeneral){
            $searchall_value = 'value="'.$keywordAll.'"';
        } else {

            $title_value = (isset($_GET['title'])) ? sanitize_text_field($_GET['title']) : '';
            $title_value = ($title_value != '') ? 'value="'.$title_value.'"' : '';

            $genre_value = (isset($_GET['genre'])) ? sanitize_text_field($_GET['genre']) : '';
            $genre_value = ($genre_value != '') ? 'value="'.$genre_value.'"' : '';

            $fromyear_value = (isset($_GET['fromyear'])) ? sanitize_text_field($_GET['fromyear']) : '';
            $fromyear_value = ($fromyear_value != '') ? 'value="'.$fromyear_value.'"' : '';

            $toyear_value = (isset($_GET['toyear'])) ? sanitize_text_field($_GET['toyear']) : '';
            $toyear_value = ($toyear_value != '') ? 'value="'.$toyear_value.'"' : '';

            $artist_value = (isset($_GET['artist'])) ? sanitize_text_field($_GET['artist']) : '';
            $artist_value = ($artist_value != '') ? 'value="'.$artist_value.'"' : '';

            $albumsearch_value = (isset($_GET['albumsearch'])) ? sanitize_text_field($_GET['albumsearch']) : '';
            $albumsearch_value = ($albumsearch_value != '') ? 'value="'.$albumsearch_value.'"' : '';
        
        }

    }

    $output = '
    <style>
    .ik_woomusicadb_form_search input {
        display: block;
        padding: 5px 7px;
        border-radius: 3px;
        margin-bottom: 20px;
        font-size: 17px;
    }
    .ik_woomusicadb_form_search .ik_woomusicadb_search_toyear, .ik_woomusicadb_form_search .ik_woomusicadb_search_fromyear{
        width: 49%;
        float: left;
        margin-right: 1%;
        max-width: 114px;
        position: relative;
    }
    .ik_woomusicadb_form_search .fromyear-input, .ik_woomusicadb_form_search .toyear-input{
        max-width: 114px;
    }
    .ik_woomusicadb_form_search div:after {
        font-size: 13px;
        position: absolute;
        bottom: -3px;
        left: 2px;
    }
    .ik_woomusicadb_form_search .ik_woomusicadb_search_toyear:after{
        content: "'. __( 'Hasta (opcional)', 'ik-musicdb' ).'";
    }
    .ik_woomusicadb_form_search .ik_woomusicadb_search_fromyear:after{
        content: "'. __( 'En / Desde', 'ik-musicdb' ).'";
    }
    .ik_woomusicadb_form_search label {
        color: #fff;
    }
    .ik_woomusicadb_search_column {
        float: left;
        padding-top: 25px;
        margin-right: 1%;
    }
    .ik_woomusicadb_search_columns, .ik_woomusicadb_search_dates{
        display: flow-root;
        position: relative;
    }
    .ik_woomusicadb_search_submit_area input{
        padding: 8px 14px;
        margin-top: 36px;
        text-transform: uppercase;
        font-weight: bold;
        font-size: 17px;
        border: 1px solid #ccc;
        border-radius: 5px;
        cursor: pointer;
    }
    .ui-datepicker{
        background: #fff;
    }    
    .music-year-datepicker a.ui-corner-all, .music-year-datepicker button.ui-datepicker-current {
        display: none;
    }
    .music-year-datepicker .ui-datepicker-title{
        min-width: 110px;
    }
    .music-year-datepicker .ui-datepicker-year{
        width: 96%;
        font-size: 20px;
        text-align: center;
        position: relative;
        left: -1.5px;
        top: 1.5px;
    }
    .music-year-datepicker {
        background-color: #fff;
        border: 1px solid #ccc;
        color: #333;
        font-size: 14px;
        margin-left: -2.5px;
    }
    .music-year-datepicker button {
        font-size: 20px;
        text-align: center;
        min-width: 110px;
        width: 90%;
        background-color: #333;
        color: #fff;
        margin: 3px auto;
        display: block;
        cursor: pointer;
    }
    @media (min-width: 980px){
        .ik_woomusicadb_search_column{
            width: 32%;
        } 
    }
    </style>
    <div class="ik_woomusicadb_form_wrapper">
        <form id="music_form_search" class="ik_woomusicadb_form_search" action="" method="get">
            <label class="labelSearch">'. __( 'Busqueda General:', 'ik-musicdb' ).'
                <input name="searchall" type="text" id="general_search" '.$searchall_value.'>
            </label>
            <hr class="line">
            <div class="ik_woomusicadb_search_columns">
                <div class="ik_woomusicadb_search_column">
                    <label class="labelSearch">'. __( 'Título: ', 'ik-musicdb' ).'
                        <input name="title" type="text" '.$title_value.'>
                    </label>
                    <label class="labelSearch">'. __( 'Artista: ', 'ik-musicdb' ).'
                        <input name="artist" type="text" '.$artist_value.'>
                    </label>
                </div>
                <div class="ik_woomusicadb_search_column">
                    <label class="labelSearch">'. __( 'Género: ', 'ik-musicdb' ).'
                        <input name="genre" type="text" '.$genre_value.'>
                    </label> 
                    <label class="labelSearch">'. __( 'Álbum: ', 'ik-musicdb' ).'
                        <input name="albumsearch" type="text" '.$albumsearch_value.'>
                    </label>
                </div>
                <div class="ik_woomusicadb_search_column">
                    <label class="labelSearch">'. __( 'Año: ', 'ik-musicdb' ).'
                        <div class="ik_woomusicadb_search_dates">
                            <div class="ik_woomusicadb_search_fromyear">
                                <input name="fromyear" class="fromyear-input" type="text" '.$fromyear_value.'>
                            </div>
                            <div class="ik_woomusicadb_search_toyear">
                                <input name="toyear" class="toyear-input" type="text" '.$toyear_value.'>
                            </div>
                        </div>
                    </label>
                </div>
            </div>
            <div class="ik_woomusicadb_search_submit_area">
            '.ik_woomusicadb_get_recaptcha().'
                <input type="submit" id="submit-btn" value="'. __( 'Buscar', 'ik-musicdb' ).'">
            </div>
        </form>
    </div>
    <script>
    jQuery(function($){
        jQuery(".fromyear-input, .toyear-input").datepicker({
            dateFormat: "yy",
            changeMonth: false,
            changeYear: true,
            showButtonPanel: true,
            yearRange: "1900:" + new Date().getFullYear(),
            onClose: function(dateText, inst) {
                jQuery(this).datepicker("widget").removeClass("music-year-datepicker");
            },
            beforeShow: function(input, inst) {
                jQuery(this).datepicker("widget").addClass("music-year-datepicker");
                var offset = jQuery(input).offset();
                var height = jQuery(input).outerHeight();
                var width = jQuery(input).outerWidth();
                setTimeout(function() {
                    inst.dpDiv.css({
                        top: (offset.top + height + 2) + "px",
                        left: (offset.left + width - inst.dpDiv.width()) + "px"
                    });
                }, 10);
            }
        }).focus(function () {
            jQuery(".ui-datepicker-month").hide();
            jQuery(".ui-datepicker-calendar").hide();;
        });
    });
    </script>';

    return $output;
    
}

//Search results music
add_shortcode('search_results_music', 'ik_woomusicadb_shortcode_results_musica');
function ik_woomusicadb_shortcode_results_musica(){

    $resultsOutput = '';

    wp_enqueue_style( 'dashicons' );

    $canciones = new Ik_MusicaDB_Canciones();
    $results = $canciones->get_songs_by_search();

    if($results !== false){
        $resultsOutput = '<div id="ik_woomusicadb_search_results">'.$results.'</div>';
    }
    
    $segundos_demo = intval(ik_woomusicdb_datainfo('demominutos')) + 2;
        
    $output = '
    <style>
    #ik_woomusicadb_search_results{
        padding: 20px 20px 30px;
    }
    .ik_woomusicadb_table_songs{
        display: table;
        width: 100%;
    }
    .ik_woomusicadb_table_songs_details{
        padding-bottom: 7px;
        display: table-caption;
    } 
    .ik_woomusicadb_table_songs_details span{
        float: left;
        margin-right: 7px;
    }  
    .ik_woomusicadb_table_songsRow, .ik_woomusicadb_table_songsRow_header {
        display: table-row;
    }
    .ik_woomusicadb_table_songsHeading {
        background-color: #EEE;
        display: table-header-group;
    }
    .ik_woomusicadb_table_songsCell, .ik_woomusicadb_table_songsHead {
        border: 1px solid #999999;
        display: table-cell;
        padding: 3px 10px;
        background: #fff;
        vertical-align: middle;
    }
    .ik_woomusicadb_table_songsHead {
        font-weight: bold;
        color: #222;
    }
    .ik_woomusicadb_table_songsHeading {
        background-color: #EEE;
        display: table-header-group;
        font-weight: bold;
    }
    .ik_woomusicadb_table_songsFoot {
        background-color: #EEE;
        display: table-footer-group;
        font-weight: bold;
    }
    .ik_woomusicadb_table_songsBody {
        display: table-row-group;
        font-size: 16px;
    }
    #ik_woomusicadb_search_results .zoomable {
        transition: transform 0.2s ease-in-out;
        cursor: pointer;
        vertical-align: middle;
        width: 70px;
    }
    #ik_woomusicadb_search_results .scalezoom img{
        transform: scale(3.5);
        z-index: 9999999;
    }
    #ik_woomusicadb_search_results .ik_woomusicadb_album_img_back_front, #ik_woomusicadb_search_results .scalezoom .ik_woomusicadb_album_img_main{
        display: none;
    }
    #ik_woomusicadb_search_results .scalezoom .ik_woomusicadb_album_img_back_front{
        display: flex;
    }
    #ik_woomusicadb_search_results .backalbum_image {
        margin-left: 250%;
    }
    #ik_woomusicadb_search_results .ik_woomusicadb_album_img, #ik_woomusicadb_search_results .ik_woomusicadb_col_add_to_cart, #ik_woomusicadb_search_results .ik_woomusicadb_col_listen {
        vertical-align: middle;
        text-align: center;
        max-width: 90px;
    }
	#ik_woomusicadb_search_results .ik_woomusicadb_table_order_num.order-asc, #ik_woomusicadb_search_results .ik_woomusicadb_table_order_num.order-desc{
        min-width: 80px;
    }
	#ik_woomusicadb_search_results .ik_woomusicadb_table_order_txt.order-asc, #ik_woomusicadb_search_results .ik_woomusicadb_table_order_txt.order-desc {
		min-width: 95px;
	}
    #ik_woomusicadb_search_results .dashicons{
        font-size: 25px;
    }
    #ik_woomusicadb_search_results .ik_woomusicadb_listen, #ik_woomusicadb_search_results .ik_woomusicadb_add_to_cart{
        text-align: center;
        cursor: pointer;
    }
    #ik_woomusicadb_search_results .ik_woomusicadb_listen {
        border-radius: 50%;
        border: 1px solid;
        width: 31px;
        height: 31px;
        margin: 0 auto;
        padding: 2.5px 2.5px 2.5px 0px;
        position: relative;
    }
    #ik_woomusicadb_search_results .ik_woomusicadb_listen .dashicons-controls-pause{
        position: relative;
        left: -1px;
    }
    #ik_woomusicadb_search_results .ik_woomusicadb_table_order_num, #ik_woomusicadb_search_results .ik_woomusicadb_table_order_txt{
        cursor: pointer;
    }
    #ik_woomusicadb_search_results .ik_woomusicadb_table_songsHead.order-asc:after, #ik_woomusicadb_search_results .ik_woomusicadb_table_songsHead.order-desc:after{
        font-family: dashicons;
        display: inline-block;
        line-height: 1;
        font-weight: 400;
        font-style: normal;
    } 
    #ik_woomusicadb_search_results .ik_woomusicadb_table_songsHead.order-asc:after{
        content: "\f142";
    } 
    #ik_woomusicadb_search_results .ik_woomusicadb_table_songsHead.order-desc:after{
        content: "\f140";
    }    
    .play-button, .adding_to_cart{
        opacity: 0;
        border: 2px solid #fff;
        animation: pulse 1s ease-out infinite;
      }
      .play-button:hover, .adding_to_cart:hover {
        opacity: 1;
      }
    .ik_woomusicadb_listen[accion=on] .ik_woomusicadb_listen_progress {
        position: absolute;
        left: 0px;
        top: 0;
        width: 31px;
        height: 31px;
        border-radius: 50%;
        border: 1px solid transparent;
        margin: 0 auto;
        padding: 2.5px 2.5px 2.5px 0px;
        border-radius: 50%;
    }
    .ik_woomusicadb_listen[accion=on] .ik_woomusicadb_listen_progress_circle {
        position: absolute;
        width: 32.5px;
        height: 32.5px;
        top: -3px;
        left: -2px;
        box-sizing: border-box;
        border: 3px solid #ccc;
        border-radius: 50%;
        animation: progress '.$segundos_demo.'s linear forwards;
}
.ik_woomusicadb_add_to_cart, .ik_woomusicadb_add_to_cart .dashicons,.ik_woomusicadb_add_to_cart:focus, .ik_woomusicadb_add_to_cart .dashicons:focus{
    outline: none;
}
.slider_album {
    position: relative;
    width: 150px;
    height: 150px;
    overflow: hidden;
}  
.slide_album {
    position: absolute;
    top: 0;
    left: 0;
    opacity: 0;
    transition: opacity 0.5s ease-in-out;
    cursor: pointer;
}
.slide_album.active {
    opacity: 1;
}
  
@keyframes progress {
  0% {
    transform: rotate(-90deg);
    border-color: #ccc transparent transparent transparent;
  }
  25% {
    border-color: #5f0000 #ccc transparent transparent;
  }
  50% {
    border-color: #5f0000 #5f0000 #ccc transparent;
  }
  75% {
    border-color: #5f0000 #5f0000 #5f0000 #ccc;
  }
  100% {
    transform: rotate(270deg);
    border-color: #5f0000 #5f0000 #5f0000 #5f0000;
  }
}
      @keyframes pulse {
        0% {
          transform: scale(0.5);
          opacity: 0.5;
        }
        50% {
          transform: scale(1);
          opacity: 1;
        }
        100% {
          transform: scale(1.5);
          opacity: 0;
        }
      }
    @media (max-width: 1290px){
        .ik_woomusicadb_hide_mobile{
            display: none;
        } 
        .ik_woomusicadb_table_songsHead.ik_woomusicadb_col_add_to_cart, .ik_woomusicadb_table_songsHead.ik_woomusicadb_col_listen{
            font-size: 0;
        }        
    }
    @media (max-width: 600px){
        #ik_woomusicadb_search_results .ik_woomusicadb_album_img{
            display: none;
        }      
        #ik_woomusicadb_search_results{
            padding: 20px 10px 30px! important;
        }
        .ik_woomusicadb_table_songsCell, .ik_woomusicadb_table_songsHead {
            padding: 3px 3.5px! important;
        }
        #ik_woomusicadb_search_results .ik_woomusicadb_col_add_to_cart .dashicons {
            font-size: 20px! important;
            position: relative;
            top: 4px;
        }
    }
    </style>
    <script>
    jQuery(document).ready(function($) {

        const images = document.querySelectorAll(".zoomable");

        images.forEach(image => {
            image.addEventListener("click", () => {
                image.classList.add("scalezoom");
            }); 
            image.addEventListener("mouseleave", () => {
                image.classList.remove("scalezoom");
            });
        });
    });
    </script>';

    $scriptOrden = "
    <script>
    // Obtener la tabla y las celdas de encabezado de la tabla
    var table = document.querySelector('.ik_woomusicadb_table_songsBody');
    var headers = table.querySelectorAll('.ik_woomusicadb_table_songsHead');
    
    // Para cada celda de encabezado, agregar un controlador de eventos de clic
    headers.forEach(function(header) {
      header.addEventListener('click', function() {
        var tableRows = table.querySelectorAll('.ik_woomusicadb_table_songsRow');
        var headerIndex = Array.from(headers).indexOf(header);
        var sortDirection = header.dataset.sort === 'asc' ? 'desc' : 'asc';
        var sortModifier = sortDirection === 'asc' ? 1 : -1;
    
        // Ordenar las filas según el contenido de la celda de la columna seleccionada
        var sortedRows = Array.from(tableRows).sort(function(a, b) {
            var aVal = a.querySelectorAll('.ik_woomusicadb_table_songsCell')[headerIndex].textContent.trim();
            var bVal = b.querySelectorAll('.ik_woomusicadb_table_songsCell')[headerIndex].textContent.trim();

            if (header.classList.contains('ik_woomusicadb_table_order_txt')) {
                return aVal > bVal ? sortModifier : -sortModifier;
            } else if (header.classList.contains('ik_woomusicadb_table_order_num')) {
                return (parseInt(aVal) - parseInt(bVal)) * sortModifier;
            }
        });
    
        // Eliminar las filas de la tabla existente y volver a agregarlas en el orden ordenado
        tableRows.forEach(function(row) {
          row.parentNode.removeChild(row);
        });
    
        sortedRows.forEach(function(sortedRow) {
          table.appendChild(sortedRow);
        });
    
        // Actualizar el atributo personalizado en el encabezado de la columna seleccionada
        headers.forEach(function(header) {
          header.dataset.sort = null;
          header.classList.remove('order-asc');
          header.classList.remove('order-desc');
        });
        header.dataset.sort = sortDirection;
        header.classList.add(sortDirection === 'asc' ? 'order-asc' : 'order-desc');
      });
    });
    
    </script>";
    
    $scriptAudio = '<div id="ik_musicadb_album_reproductor" cancion_id="0"></div>
    <script>
    jQuery(document).ready(function($) {
        //Iniciar cancion
        var cancionRep = new Audio("");
        
        cancionRep.addEventListener("loadstart", function(){ 
            var cancion_id_actual = jQuery("#ik_musicadb_album_reproductor").attr("cancion_id");
            
            //Pongo en play todas las pistas menos la reproduccion actual
            jQuery("#ik_woomusicadb_search_results .ik_woomusicadb_table_songsCell .ik_woomusicadb_listen").each(function() {
                if (jQuery(this).attr("data_id") != cancion_id_actual){
                    jQuery(this).find(".dashicons").removeClass("dashicons-controls-pause");
                    jQuery(this).find(".dashicons").addClass("dashicons-controls-play");
                }
            });
        });
        
		cancionRep.onended = function(){
			jQuery("#ik_musicadb_album_reproductor .reproductor_control").attr("estado", "off");
			jQuery("#ik_musicadb_album_reproductor .reproductor_control .dashicons").removeClass("dashicons-controls-pause");
			jQuery("#ik_musicadb_album_reproductor .reproductor_control .dashicons").addClass("dashicons-controls-play");
			cancionRep.pause();			
			var cancion_id = jQuery("#ik_musicadb_album_reproductor").attr("cancion_id");
            		var elemento_cancion = jQuery("#ik_woomusicadb_search_results .ik_woomusicadb_table_songsCell .ik_woomusicadb_listen[data_id="+cancion_id+"]");

			elemento_cancion.find(".dashicons").removeClass("dashicons-controls-pause");
			elemento_cancion.find(".dashicons").addClass("dashicons-controls-play");
			elemento_cancion.attr("accion", "off");	
		}

        function ik_musicadb_reproducir_musica(elemento_cancion){
            cancionRep.play();
    
            jQuery("#ik_musicadb_album_reproductor .reproductor_control .dashicons").removeClass("dashicons-controls-play");
            jQuery("#ik_musicadb_album_reproductor .reproductor_control .dashicons").addClass("dashicons-controls-pause");
            jQuery("#ik_musicadb_album_reproductor .reproductor_control").attr("estado", "on");
            elemento_cancion.removeClass("dashicons-controls-play");
            elemento_cancion.find(".dashicons").addClass("dashicons-controls-pause");		
            jQuery(elemento_cancion).attr("accion", "on");		
        }
        
        function ik_musicadb_pausar_musica(elemento_cancion){
            cancionRep.pause();
            
            jQuery("#ik_musicadb_album_reproductor .reproductor_control .dashicons").removeClass("dashicons-controls-pause");
            jQuery("#ik_musicadb_album_reproductor .reproductor_control .dashicons").addClass("dashicons-controls-play");	
            jQuery("#ik_musicadb_album_reproductor .reproductor_control").attr("estado", "off");
            elemento_cancion.removeClass("dashicons-controls-pause");
            elemento_cancion.find(".dashicons").addClass("dashicons-controls-play");	
            jQuery(elemento_cancion).attr("accion", "off");				
        }

        //Para o empezar reproduccion
        jQuery("body").on("click", "#ik_musicadb_album_reproductor .reproductor_control", function(){
            var estado_rep = jQuery("#ik_musicadb_album_reproductor .reproductor_control").attr("estado");
            
            var cancion_id = jQuery("#ik_musicadb_album_reproductor").attr("cancion_id");
            var elemento_cancion = jQuery("#ik_woomusicadb_search_results .ik_woomusicadb_table_songsCell .ik_woomusicadb_listen[data_id="+cancion_id+"] .dashicons");
            
            if (estado_rep == "off"){
                ik_musicadb_reproducir_musica(elemento_cancion);
            } else {
                ik_musicadb_pausar_musica(elemento_cancion);				
            }
        });

        //Reproduccion de canciones
        function ik_musicadb_script_reproducir(url_cancion){		
            cancionRep.setAttribute("src", url_cancion);
    
            cancionRep.oncanplaythrough = function(){
                
                var cancion_id = jQuery("#ik_musicadb_album_reproductor").attr("cancion_id");
                cancionRep.play();
                var duration = cancionRep.duration;
                var duracion_cancion_min = Math.floor(duration / 60);
                var duracion_cancion_min = (duracion_cancion_min >= 10) ? duracion_cancion_min : "0" + duracion_cancion_min;
                var duracion_cancion_sec = Math.floor(duration % 60);
                var duracion_cancion_sec = (duracion_cancion_sec >= 10) ? duracion_cancion_sec : "0" + duracion_cancion_sec;			
                var duracion_cancion = duracion_cancion_min +":"+duracion_cancion_sec;
    
                
                jQuery("#ik_musicadb_album_reproductor .cancion_tiempototal").text("-"+duracion_cancion);
        
                cancionRep.addEventListener("timeupdate", function(){ ik_actualizar_tiempo(); });
                
                function ik_actualizar_tiempo(){
                    
                    var currentTime = cancionRep.currentTime;
                    
                    var cancion_reproduciendo_min = Math.floor(currentTime / 60);
                    var cancion_reproduciendo_min = (cancion_reproduciendo_min >= 10) ? cancion_reproduciendo_min : "0" + cancion_reproduciendo_min;
                    var cancion_reproduciendo_sec = Math.floor(currentTime % 60);
                    var cancion_reproduciendo_sec = (cancion_reproduciendo_sec >= 10) ? cancion_reproduciendo_sec : "0" + cancion_reproduciendo_sec;
                    var cancion_reproduciendo = cancion_reproduciendo_min +":"+cancion_reproduciendo_sec;
                    jQuery("#ik_musicadb_album_reproductor .cancion_reproduciendo").text(cancion_reproduciendo);	
                            
                }
                
                return false;
            }
        }
        document.addEventListener("DOMContentLoaded", function() {
            var slider = document.querySelector(".slider");
            var slides = slider.querySelectorAll(".slide");
            var activeSlideIndex = 0;
          
            slides[activeSlideIndex].addEventListener("click", function() {
              slides[activeSlideIndex].classList.remove("active");
                 activeSlideIndex = (activeSlideIndex + 1) % slides.length;
          
              slides[activeSlideIndex].classList.add("active");
            });
          });
          
        jQuery(".ik_woomusicadb_listen").click(function(e) {
            e.preventDefault();
            var control = jQuery(this);
            var audioId = control.attr("data_id");
            var reproductor = jQuery("#ik_musicadb_album_reproductor");

            if (control.attr("accion") != "on" && reproductor.attr("procesando") != "1"){
	            control.addClass("play-button");
                reproductor.attr("procesando","1");
        
                // Hacer la solicitud AJAX
                jQuery.ajax({
                    url: "'.admin_url('admin-ajax.php').'",
                    type: "POST",
                    data: {
                        action: "ik_woomusicadb_audio_url_segs",
                        audio_id: audioId,
                    },
                    success: function(response) {
                        var audioUrl = response.data;
                        if (window.innerWidth < 767) {
	                        if (jQuery("#ik_woomusicadb_audio_player").length > 0) {
	                            const audio = document.getElementById("ik_woomusicadb_audio_player");
			                    audio.pause();
			          jQuery("#ik_woomusicadb_search_results .ik_woomusicadb_table_songsCell .ik_woomusicadb_listen").each(function() {
		                            jQuery(this).find(".dashicons").removeClass("dashicons-controls-pause");
		                            jQuery(this).find(".dashicons").addClass("dashicons-controls-play");
		                            jQuery(this).attr("accion", "off");
			                        jQuery(this).find(".dashicons").removeClass("dashicons-controls-pause");
		                            jQuery(this).find(".dashicons").addClass("dashicons-controls-play");
		                    });
                            jQuery("#ik_woomusicadb_audio_player").remove();
			          
				            }
            			    var audioElement = jQuery("<audio id=\"ik_woomusicadb_audio_player\" style=\"display:none\" audioId =\""+audioId +"\">");
                            audioElement.attr("src", audioUrl);
                            jQuery("body").append(audioElement);
	                        reproductor.addClass("activo");
	                        reproductor.attr("cancion_id", audioId);
                            
                            // reproduce el archivo MP3
                            audioElement.get(0).play();
                            control.attr("accion", "on");
                			control.removeClass("play-button");
                			reproductor.removeAttr("procesando");
                			control.find(".dashicons").removeClass("dashicons-controls-play");
		                    control.find(".dashicons").addClass("dashicons-controls-pause");
		                                jQuery("#ik_musicadb_album_reproductor .reproductor_control .dashicons").removeClass("dashicons-controls-pause");
            jQuery("#ik_musicadb_album_reproductor .reproductor_control .dashicons").addClass("dashicons-controls-play");	
            jQuery("#ik_musicadb_album_reproductor .reproductor_control").attr("estado", "off");
            elemento_cancion.removeClass("dashicons-controls-pause");
            elemento_cancion.find(".dashicons").addClass("dashicons-controls-play");	
            jQuery(elemento_cancion).attr("accion", "off");	

            			} else {                        
	                        reproductor.addClass("activo");
	                        reproductor.attr("cancion_id", audioId);
	                        setTimeout(function(){
	                        	jQuery("#ik_woomusicadb_search_results .ik_woomusicadb_table_songsCell .ik_woomusicadb_listen").each(function() {
		                                jQuery(this).find(".dashicons").removeClass("dashicons-controls-pause");
		                                jQuery(this).find(".dashicons").addClass("dashicons-controls-play");
		                            	jQuery(this).removeAttr("accion");
		                        });
		                        ik_musicadb_script_reproducir(audioUrl);
		                        control.find(".dashicons").removeClass("dashicons-controls-play");
		                        control.find(".dashicons").addClass("dashicons-controls-pause");
		                        control.attr("accion", "on");
		                        reproductor.removeAttr("procesando");
		                        control.removeClass("play-button");
	                        }, 1200);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error("AJAX error: " + status + " - " + error);
                        reproductor.removeAttr("procesando");
                        control.removeClass("play-button");
                    },
                });
            } else if (control.attr("accion") == "on"  && reproductor.attr("procesando") != "1"){
	            if (window.innerWidth < 767) {
                    const audio = document.getElementById("ik_woomusicadb_audio_player");
			        audio.pause();
		          jQuery("#ik_woomusicadb_search_results .ik_woomusicadb_table_songsCell .ik_woomusicadb_listen").each(function() {
		                            jQuery(this).find(".dashicons").removeClass("dashicons-controls-pause");
		                            jQuery(this).find(".dashicons").addClass("dashicons-controls-play");
		                            jQuery(this).attr("accion", "off");
			                        jQuery(this).find(".dashicons").removeClass("dashicons-controls-pause");
		                            jQuery(this).find(".dashicons").addClass("dashicons-controls-play");
		                    });
		            
            } else {
                ik_musicadb_pausar_musica(control);
                }
            }
        });
        jQuery(".ik_woomusicadb_add_to_cart").on("click", function() {
            var audio_id = jQuery(this).attr("data_id");
            var add_to_cart_button = jQuery(this);            
            add_to_cart_button.addClass("adding_to_cart");
            jQuery.ajax({
                url: "'.admin_url('admin-ajax.php').'",
                method: "POST",
              data: {
                action: "ik_woomusicadb_add_song_to_cart",
                audio_id: audio_id
              },
              success: function(response) {
                jQuery("body").trigger("wc_fragment_refresh");
                add_to_cart_button.removeClass("adding_to_cart");
              },
              error: function(error) {
                add_to_cart_button.removeClass("adding_to_cart");
              }
            });
        });
    });
    </script>';

    $output .= $resultsOutput.$scriptOrden.$scriptAudio;

    return $output;
    
}