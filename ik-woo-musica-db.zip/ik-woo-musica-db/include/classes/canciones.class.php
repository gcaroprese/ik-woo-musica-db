<?php
/*

Class Ik_MusicaDB_Canciones
Update: 13/03/2022
Author: Gabriel Caroprese

*/


if ( ! defined( 'ABSPATH' ) ) {
    return;
}
 
class Ik_MusicaDB_Canciones{
    
    protected $db_table_canciones;
    
    public function __construct(){
        global $wpdb;
        $this->db_table_canciones = $wpdb->prefix.'ik_musicadb_canciones';
    }
    
    //Crear cancion
    public function crear_cancion($args){

        $titulo = (isset($args['titulo'])) ? sanitize_text_field($args['titulo']) : 'Sin nombre';
        $titulo = str_replace('\\', '', $titulo);
        $interpretes = (isset($args['interpretes'])) ? sanitize_text_field($args['interpretes']) : 'Sin nombre';
        $interpretes = str_replace('\\', '', $interpretes);
        $banda = (isset($args['band'])) ? sanitize_text_field($args['band']) : 'Sin nombre';
        $banda = str_replace('\\', '', $banda);
        $id_file = (isset($args['attachment_id'])) ? absint($args['attachment_id']) : false;
        $id_album = (isset($args['album_id'])) ? absint($args['album_id']) : 0;
        $album = (isset($args['album'])) ? sanitize_text_field($args['album']) : 'Sin nombre';
        $album = str_replace('\\', '', $album);
        $year = (isset($args['year'])) ? absint($args['year']) : '0000';
        $track_n = (isset($args['numero_pista'])) ? absint($args['numero_pista']) : 1;
        $genero = (isset($args['genero'])) ? sanitize_text_field($args['genero']) : 'N/A';
        $genero = str_replace('\\', '', $genero);
        $duracion_segundos = (isset($args['duracion_segundos'])) ? absint($args['duracion_segundos']) : 0;
        $duracion = (isset($args['duracion'])) ? absint($args['duracion']) : 0;
        $descripcion = (isset($args['descripcion'])) ? sanitize_textarea_field($args['descripcion']) : '';
        $descripcion = str_replace('\\', '', $descripcion);
        $url_audio = (isset($args['url_audio'])) ? esc_url($args['url_audio']) : '';
        
        if($id_file){
            global $wpdb;

            $args_insert  = array (
                    'titulo'=>$titulo,	
                    'interpretes'=>$interpretes,
                    'band'=>$banda,
                    'attachment_id'=>$id_file,	
                    'album_id'=>$id_album,	
                    'album'=>$album,	
                    'year'=>$year,	
                    'numero_pista'=>$track_n,	
                    'genero'=>$genero,	
                    'duracion_segundos'=>$duracion_segundos,	
                    'duracion'=>$duracion,	
                    'tiempo_subido'=>current_time( 'mysql' ),	
                    'tiempo_editado'=>current_time( 'mysql' ),
                    'descripcion'=>$descripcion,
                    'url_audio'=>$url_audio,
            );
            $rowResult = $wpdb->insert($this->db_table_canciones, $args_insert);  
            return $wpdb->insert_id; 

        } else {
            return false;
        }
       
    }
    
    //Devolver attachment ID de cancion por ID
    public function get_attachment_id_cancion($cancion_id){
        $cancion_id = absint($cancion_id);
        
        if ($cancion_id > 0){
            global $wpdb;
            $woomusicadb_canciones_query = "SELECT * FROM ".$this->db_table_canciones." WHERE id = ".$cancion_id;
            $canciones = $wpdb->get_results($woomusicadb_canciones_query);
            
            if (isset($canciones[0]->attachment_id)){
                return $canciones[0]->attachment_id;
            }        
        }
        
        return 0;
    }
    
    //Eliminar cancion por ID
    public function eliminar_cancion_por_id($cancion_id){
        if(current_user_can( 'administrator' )){
            $cancion_id = absint($cancion_id);
            global $wpdb;
            $wpdb->delete( $this->db_table_canciones , array( 'id' => $cancion_id ) );
            return true;
        } else {
            return false;
        }
    }
    
    //devolver URL de cancion
    public function get_url($cancion_id){
        $cancion_id = absint($cancion_id);
            
        //por si no se encuentra nada
        $datos_cancion = 'error';
        
        if ($cancion_id > 0){
        
            global $wpdb;
            $querycancion = "SELECT * FROM ".$this->db_table_canciones." WHERE id = ".$cancion_id;
            $cancion = $wpdb->get_results($querycancion);
    
            if (isset($cancion[0]->id)){
    			
    			$datos_cancion = NULL;
    			$datos_cancion['url'] = $cancion[0]->url_audio;
    			$datos_cancion['titulo'] = $cancion[0]->titulo;
    			$datos_cancion['autor'] = $cancion[0]->interpretes;
    			$datos_cancion['attachment_id'] = $cancion[0]->attachment_id;
    			$datos_cancion['album_id'] = $cancion[0]->album_id;
    		}
        }
        
        return $datos_cancion;
    }
    
    //Listo canciones según album ID
    public function get_canciones_album($album_id, $uso = 'backend'){
        $listado_canciones = '';
        $album_id = absint($album_id);

        if($uso == 'backend'){
            
            //Boton para agregar canciones para luego de la lista
            $_boton_agregar = '<button album_id="'.$album_id.'" class="button page-title-action ik_woomusicadb_agregar_canciones">Agregar Canciones</button>';
            
            if ($album_id != 0){
                global $wpdb;
                $woomusicadb_canciones_query = "SELECT * FROM ".$this->db_table_canciones." WHERE album_id = ".$album_id." ORDER BY ABS(numero_pista)";
                $canciones = $wpdb->get_results($woomusicadb_canciones_query);
                
                if (isset($canciones[0]->id)){
                    $listado_canciones .= '<ul class="ik_musicadb_lista_canciones">';
                    foreach ($canciones as $cancion){
                        //# de pista
                        $pista_n = absint($cancion->numero_pista);    
                        
                        $listado_canciones .= '<li cancion_id="'.$cancion->id.'"><span class="canciones_acciones"><span class="dashicons dashicons-controls-play"></span></span><span class="cancion_editar">'.$pista_n.'- '.$cancion->titulo.'</span><div class="editar_opciones_cancion"><span class="ik_editar_cancion dashicons dashicons-edit"></span><span class="ik_eliminar_cancion dashicons dashicons-trash"></span></div></li>'; 
                    }
                    
                    $listado_canciones .= '</ul>';
        
                }        
            }
            
            $listado_canciones = $listado_canciones.$_boton_agregar;

        } else {
            if ($album_id != 0){
                global $wpdb;
                $woomusicadb_canciones_query = "SELECT * FROM ".$this->db_table_canciones." WHERE album_id = ".$album_id." ORDER BY ABS(numero_pista)";
                $canciones = $wpdb->get_results($woomusicadb_canciones_query);
                
                if (isset($canciones[0]->id)){
                    $listado_canciones .= '<ul class="ik_musicadb_lista_canciones">';
                    foreach ($canciones as $cancion){
                        //# de pista
                        $pista_n = absint($cancion->numero_pista);    
                        
                        $listado_canciones .= '<li><span class="n-pista">'.$pista_n.'- '.$cancion->titulo.'</span></li>'; 
                    }
                    
                    $listado_canciones .= '</ul>';
        
                }        
            }           
        }
        
        return $listado_canciones;
    }

    //editar nombre y n de pista
    public function editar_nombre_pista($cancion_id, $ntrack, $nombre_cancion){
        $cancion_id = absint($cancion_id);
        $ntrack = absint($ntrack);
        $nombre_cancion = sanitize_text_field($nombre_cancion);
        $nombre_cancion = str_replace('\\', '', $nombre_cancion);
        
        if ($cancion_id > 0){
    		if ($ntrack > 0){
    			$dato_cancion['numero_pista']  = $ntrack;
    		}
    		
    		if ($nombre_cancion !== '' && $nombre_cancion !== ' '){
    			$dato_cancion['titulo']  = $nombre_cancion;
    		}
    		
    		if (isset($dato_cancion)){
    		    $dato_cancion['tiempo_editado'] =	current_time( 'mysql' );
    		    
        		global $wpdb;
        		$where = [ 'id' => $cancion_id ];    		    
        		$rowResult = $wpdb->update($this->db_table_canciones, $dato_cancion , $where);
        		
        		return true;
    		}
        }
    		
    	return false;
    }
    
    //eliminar canciones por album_id
    public function eliminar_por_album_id($album_id){
        $album_id = absint($album_id);
        global $wpdb;
        $wpdb->delete( $this->db_table_canciones , array( 'album_id' => $album_id ) );
        return true;
    }
    
    //eliminar canciones por attachment_id
    public function eliminar_por_attachment_id($attachment_id){
        $attachment_id = absint($attachment_id);
        global $wpdb;
        $wpdb->delete( $this->db_table_canciones , array( 'attachment_id' => $attachment_id ) );
        return true;
    }

    //Listar total de registros / canciones subidas 
    private function get_total_records(){
        global $wpdb;

        // Consulta SQL para contar los registros
        $query = "SELECT COUNT(*) FROM ".$this->db_table_canciones;

        // Ejecutar la consulta y obtener el resultado
        $total = $wpdb->get_var($query);

        return $total;
    }

    //Listar total de albums basado en la tabla de canciones
    private function get_total_albums(){
        global $wpdb;
    
        // Consulta SQL para contar los registros con valores no repetidos en la columna album_id
        $query = "SELECT COUNT(DISTINCT album_id) FROM ".$this->db_table_canciones;
    
        // Ejecutar la consulta y obtener el resultado
        $total = $wpdb->get_var($query);
    
        return $total;
    }

    //Listar fecha de la última canción actualizada
    private function get_last_edit(){
        global $wpdb;

        // Consulta SQL para contar los registros
        $query = "SELECT tiempo_editado FROM ".$this->db_table_canciones." ORDER BY tiempo_editado DESC LIMIT 1";

        // Ejecutar la consulta y obtener el resultado
        $tiempo_editado = $wpdb->get_var($query);
        $tiempo_editado = date('Y-m-d', strtotime($tiempo_editado));

        return $tiempo_editado;
    }

    //Listar canciones
    public function get_songs_by_search(){
        
        if (isset($_GET['searchall'])  || isset($_GET['title'])  || isset($_GET['genre'])  || isset($_GET['fromyear'])  || isset($_GET['toyear'])  || isset($_GET['artist'])  || isset($_GET['albumsearch'])){

            //Si hay recaptcha
            $recapchaEnabled = get_option('ik_woomusicadb_recaptcha_use');
            $recapchaEnabled = ($recapchaEnabled != false && $recapchaEnabled != '0' && $recapchaEnabled != NULL) ? true : false;

            if($recapchaEnabled){
                if (!isset($_GET['g-recaptcha-response'])) {
                    return '<div id="ik_woomusicadb_search_results">'. __( 'Validá que no seas un robot.', 'ik-musicdb' ).'</div>';
                }
            }

            //check if I have to search customized or just search in general
            $keywordAll = (isset($_GET['searchall'])) ? sanitize_text_field($_GET['searchall']) : '';
            $keywordAll = (!empty($keywordAll) && $keywordAll != '' && $keywordAll != ' ') ? $keywordAll : false;     
            
            //make sure values are not empty neither
            if($keywordAll == false){
                $title_keyword = (isset($_GET['title'])) ? sanitize_text_field($_GET['title']) : '';
                $title_keyword = (!empty($title_keyword) || $title_keyword != '' || $title_keyword != ' ') ? $title_keyword : false; 
                
                $genre_keyword = (isset($_GET['genre'])) ? sanitize_text_field($_GET['genre']) : '';
                $genre_keyword = (!empty($genre_keyword) || $genre_keyword != '' || $genre_keyword != ' ') ? $genre_keyword : false; 

                $fromyear_keyword = (isset($_GET['fromyear'])) ? sanitize_text_field($_GET['fromyear']) : '';
                $fromyear_keyword = (!empty($fromyear_keyword) || $fromyear_keyword != '' || $fromyear_keyword != ' ') ? $fromyear_keyword : false; 

                $toyear_keyword = (isset($_GET['toyear'])) ? sanitize_text_field($_GET['toyear']) : '';
                $toyear_keyword = (!empty($toyear_keyword) || $toyear_keyword != '' || $toyear_keyword != ' ') ? $toyear_keyword : false; 

                $artist_keyword = (isset($_GET['artist'])) ? sanitize_text_field($_GET['artist']) : '';
                $artist_keyword = (!empty($artist_keyword) || $artist_keyword != '' || $artist_keyword != ' ') ? $artist_keyword : false; 

                $album_keyword = (isset($_GET['albumsearch'])) ? sanitize_text_field($_GET['albumsearch']) : '';
                $album_keyword = (!empty($album_keyword) || $album_keyword != '' || $album_keyword != ' ') ? $album_keyword : false; 
            }

            if ($keywordAll  || $title_keyword || $genre_keyword || $fromyear_keyword || $toyear_keyword || $artist_keyword || $album_keyword){
                
                $where = '';
                
                $orderdir = (isset($_GET['order'])) ? sanitize_text_field($_GET['order']) : 'ASC';
                $orderdir = ($orderdir !== 'ASC') ? 'DESC' : 'ASC';

                $offset = 'LIMIT 100';

                $albums = new Ik_MusicaDB_Albums();
                
                global $wpdb;
                $tabla_albums = $albums->get_album_table();
                $tabla_songs = $this->db_table_canciones;

                $orderby = (isset($_GET['orderby'])) ? sanitize_text_field($_GET['orderby']) : $tabla_songs.'.titulo';

                if ($orderby == 'nombre'){
                    $orderby = $tabla_albums.'.nombre';
                } else if ($orderby == 'interpretes'){
                    $orderby = $tabla_albums.'.interpretes';
                } else if ($orderby == 'tiempo_editado'){
                    $orderby = $tabla_albums.'.tiempo_editado';
                } else if ($orderby == 'year'){
                    $orderby = $tabla_albums.'year';
                } else if ($orderby == 'genero'){
                    $orderby = $tabla_albums.'.genero';
                }

                $queryToSelect = $tabla_albums.', '.$tabla_songs;

                if($keywordAll == false){

                    $querywhere = '';
                    //busca por los diferentes terminos
                    if ($title_keyword){
                        $querywhere .= "(".$tabla_albums.".id = ".$tabla_songs.".album_id AND
                        ".$tabla_songs.".titulo LIKE '%".$title_keyword."%') AND ";
                    }

                    if ($genre_keyword){
                        $querywhere .= "(".$tabla_albums.".id = ".$tabla_songs.".album_id AND
                        ".$tabla_albums.".genero LIKE '%".$genre_keyword."%') AND ";
                    }

                    if ($fromyear_keyword || $toyear_keyword){

                        if ($fromyear_keyword && $toyear_keyword){
                            $querywhere .= "(".$tabla_albums.".id = ".$tabla_songs.".album_id AND
                            ".$tabla_songs.".year BETWEEN ".$fromyear_keyword." AND ".$toyear_keyword.") AND ";
                        } else if($fromyear_keyword){
                            $querywhere .= "(".$tabla_albums.".id = ".$tabla_songs.".album_id AND
                            ".$tabla_songs.".year LIKE '%".$fromyear_keyword."%') AND ";
                        }
                    }

                    if ($artist_keyword){
                        $querywhere .= "(".$tabla_albums.".id = ".$tabla_songs.".album_id AND
                        ".$tabla_songs.".interpretes LIKE '%".$artist_keyword."%') AND ";
                    }

                    if ($album_keyword){
                        $querywhere .= "(".$tabla_albums.".id = ".$tabla_songs.".album_id AND
                        ".$tabla_albums.".nombre LIKE '%".$album_keyword."%') AND ";
                    }

                    if($querywhere != ''){

                        $querywhere = 'WHERE '.$querywhere;
                        //borro el ultimo AND
                        $querywhere = substr($querywhere, 0, -5);
                    }

                } else {
                    //busqueda general
                    $querywhere = "WHERE (".$tabla_albums.".id = ".$tabla_songs.".album_id) AND 
                    (".$tabla_albums.".nombre LIKE '%".$keywordAll."%' OR 
                    ".$tabla_albums.".year LIKE '%".$keywordAll."%' OR 
                    ".$tabla_albums.".descripcion LIKE '%".$keywordAll."%' OR 
                    ".$tabla_albums.".interpretes LIKE '%".$keywordAll."%' OR 
                    (".$tabla_albums.".id = ".$tabla_songs.".album_id AND
                    ".$tabla_songs.".titulo LIKE '%".$keywordAll."%') OR
                    (".$tabla_albums.".id = ".$tabla_songs.".album_id AND 
                    ".$tabla_songs.".interpretes LIKE '%".$keywordAll."%') OR
                    (".$tabla_albums.".id = ".$tabla_songs.".album_id AND
                    ".$tabla_songs.".band LIKE '%".$keywordAll."%'))";
                    
                }
                
                $querycanciones = "SELECT DISTINCT ".$tabla_albums.".nombre, ".$tabla_albums.".genero, ".$tabla_albums.".id_imgs, ".$tabla_albums.".year, ".$tabla_songs.".id, ".$tabla_songs.".numero_pista, ".$tabla_songs.".titulo, ".$tabla_songs.".interpretes, ".$tabla_songs.".duracion_segundos FROM ".$queryToSelect." ".$querywhere." 
                ORDER BY ".$orderby." ".$orderdir." ".$offset;        

                $cancionesEncontrados = $wpdb->get_results($querycanciones);
                
                // I assign values for comments from admin and translator
                if (isset($cancionesEncontrados[0]->id)){

                    $total = count($cancionesEncontrados);

                    // Cuento albums
                    $unique_albums = array_unique(array_column($cancionesEncontrados, 'nombre'));
                    $total_albums = count($unique_albums);

                    // Cuento artistas
                    $unique_artistas = array_unique(array_column($cancionesEncontrados, 'interpretes'));
                    $total_artistas = count($unique_artistas);

                    //to link search for albums
                    $url_search = get_option('ik_woomusicadb_url_search');

                    //cambio la url search basado en el idioma
                    if(function_exists('pll_default_language') && function_exists('pll_current_language')){
                        $default_language = pll_default_language(); // Obtener el idioma predeterminado de Polylang
                        $current_language = pll_current_language(); // Obtener el idioma actual de la página
                    
                        if ($default_language !== $current_language) {

                            $post_id = url_to_postid($url_search);

                            if ($post_id) {
                                // Obtener el permalink correspondiente al ID de la entrada en el idioma actual
                                $language_permalink = get_permalink(pll_get_post($post_id));
                                $url_search = $language_permalink;
                            }
                        }
                    }

                    $output = '
                    <div class="ik_woomusicadb_table_songs">
                        <div class="ik_woomusicadb_table_songs_details">
                        <span>'. __( 'Buscando entre ', 'ik-musicdb' ).$this->get_total_records().' '. __( 'registros', 'ik-musicdb' ).'   |</span>
                        <span> '.$this->get_total_albums().' '. __( 'Álbums', 'ik-musicdb' ).'   |</span>
                        <span>'. __( 'Última Actualización', 'ik-musicdb' ).': '.$this->get_last_edit().'</span>
                        </div>
                        <div class="ik_woomusicadb_table_songs_details">
                            <span>'. __( 'Resultados', 'ik-musicdb' ).': '.$total .'   |</span>
                            <span>'. __( 'Albums', 'ik-musicdb' ).': '.$total_albums.'   |</span> 
                            <span>'. __( 'Artistas', 'ik-musicdb' ).': '.$total_artistas.'   |</span>
                            <span>'. __( 'Precio por pista', 'ik-musicdb' ).': $'.number_format( floatval(ik_woomusicdb_datainfo('preciopista')), 2, '.', ''  ).' USD</span>
                        </div>
                        <div class="ik_woomusicadb_table_songsBody">
                            <div class="ik_woomusicadb_table_songsRow_header">
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_col_listen">'. __( 'Escuchar', 'ik-musicdb' ).'</div>
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_album_img">'. __( 'Tapa', 'ik-musicdb' ).'</div>
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_table_order_num ik_woomusicadb_hide_mobile">'. __( 'Pista', 'ik-musicdb' ).'</div>
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_table_order_txt order-asc" data-sort="asc">'. __( 'Título', 'ik-musicdb' ).'</div>
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_table_order_txt ik_woomusicadb_hide_mobile">'. __( 'Género', 'ik-musicdb' ).'</div>
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_table_order_txt">'. __( 'Artista', 'ik-musicdb' ).'</div>
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_table_order_txt ik_woomusicadb_hide_mobile">'. __( 'Álbum', 'ik-musicdb' ).'</div>
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_table_order_num">'. __( 'Año', 'ik-musicdb' ).'</div>
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_table_order_num ik_woomusicadb_hide_mobile">'. __( 'Dur.', 'ik-musicdb' ).'</div>
                                <div class="ik_woomusicadb_table_songsHead ik_woomusicadb_col_add_to_cart">'. __( 'Comprar', 'ik-musicdb' ).'</div>
                            </div>';

                    foreach($cancionesEncontrados as $cancionEncontrada){


                        //Conseguir URL de thumbnail de tapa de album
                        $tapa_id_img_ids = (is_serialized($cancionEncontrada->id_imgs)) ? maybe_unserialize($cancionEncontrada->id_imgs) : 0;
                        $tapa_id_img = (isset($tapa_id_img_ids[0])) ? absint($tapa_id_img_ids[0]) : 0;
                        $contratapa_id_img = (isset($tapa_id_img_ids[1])) ? absint($tapa_id_img_ids[1]) : 0;
                        $tapa_album_url_array = wp_get_attachment_image_src( $tapa_id_img, 'thumbnail' );
                        $contratapa_album_url_array = wp_get_attachment_image_src( $contratapa_id_img, 'thumbnail' );

                        $thumbnail_tapa = (isset($tapa_album_url_array[0])) ? '<img class="zoomable_image" title="'. __( 'Click para ampliar', 'ik-musicdb' ).'" src="'.$tapa_album_url_array[0].'" alt="abum '.$cancionEncontrada->nombre.'" />' : '';
                        $thumbnail_tapa_zoom = (isset($tapa_album_url_array[0])) ? '<img class="zoomable_image" src="'.$tapa_album_url_array[0].'" alt="abum '.$cancionEncontrada->nombre.'" />' : '';
                        $thumbnail_contratapa = (isset($contratapa_album_url_array[0])) ? '<img class="zoomable_image backalbum_image" src="'.$contratapa_album_url_array[0].'" alt="abum '.$cancionEncontrada->nombre.'" />' : '';

                        //convierto segundos en minutos
                        $segundos = $cancionEncontrada->duracion_segundos;
                        $minutos = intval($segundos / 60);
                        $segundos_restantes = $segundos % 60;
                        $segundos_formateados = sprintf('%02d', $segundos_restantes);
                        $duracion = $minutos . ':' . $segundos_formateados;

                        $output .= '
                        <div class="ik_woomusicadb_table_songsRow">
                            <div class="ik_woomusicadb_table_songsCell ik_woomusicadb_col_listen">
                                <div class="ik_woomusicadb_listen" data_id="'.$cancionEncontrada->id.'">
                                    <span class="dashicons dashicons-controls-play"></span>
                                     <div class="ik_woomusicadb_listen_progress">
                                     	<div class="ik_woomusicadb_listen_progress_circle"></div>
                                     </div>
                                </div>
                            </div>
                            <div class="ik_woomusicadb_table_songsCell ik_woomusicadb_album_img zoomable">
                                <div class="ik_woomusicadb_album_img_main">
                                '.$thumbnail_tapa.'
                                </div>
                                <div class="ik_woomusicadb_album_img_back_front">
                                '.$thumbnail_tapa_zoom.$thumbnail_contratapa.'
                                </div>
                            </div>
                            <div class="ik_woomusicadb_table_songsCell ik_woomusicadb_hide_mobile">'.$cancionEncontrada->numero_pista.'</div>
                            <div class="ik_woomusicadb_table_songsCell">'.$cancionEncontrada->titulo.'</div>
                            <div class="ik_woomusicadb_table_songsCell ik_woomusicadb_hide_mobile">'.$cancionEncontrada->genero.'</div>
                            <div class="ik_woomusicadb_table_songsCell">'.$cancionEncontrada->interpretes.'</div>
                            <div class="ik_woomusicadb_table_songsCell ik_woomusicadb_hide_mobile">
                                <a href="'.$url_search.'?searchall='.$cancionEncontrada->nombre.'&g-recaptcha-response=0&g-recaptcha-response=0">
                            '.$cancionEncontrada->nombre.'</a>
                            </div>
                            <div class="ik_woomusicadb_table_songsCell">'.$cancionEncontrada->year.'</div>
                            <div class="ik_woomusicadb_table_songsCell ik_woomusicadb_hide_mobile">'.$duracion.'</div>
                            <div class="ik_woomusicadb_table_songsCell ik_woomusicadb_col_add_to_cart">
                                <div class="ik_woomusicadb_add_to_cart" data_id="'.$cancionEncontrada->id.'">
                                    <span class="dashicons dashicons-cart"></span>
                                </div>
                            </div>
                        </div>';

                    }
                    
                    $output .= '</div>
                        </div>';

                    return $output;
                } else {
                    return '<div id="ik_woomusicadb_search_results">'. __( 'No se encontraron resultados.', 'ik-musicdb' ).'</div>';
                }
            }
        }

        return false;
    }    

}

?>