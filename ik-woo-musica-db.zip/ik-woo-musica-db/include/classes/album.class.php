<?php
/*

Class Ik_MusicaDB_Albums
Update: 13/03/2022
Author: Gabriel Caroprese

*/

if ( ! defined( 'ABSPATH' ) ) {
    return;
}

class Ik_MusicaDB_Albums extends Ik_MusicaDB_Canciones{

    protected $db_table_albums;
    
    public function __construct(){
        global $wpdb;
        $this->db_table_albums = $wpdb->prefix.'ik_musicadb_albums';
    }

    public function get_album_table(){
        return $this->db_table_albums;
    }
    
    //Crear un album de forma sencilla por su nombre
    public function crear_album($album_nombre){
        $album_nombre = sanitize_text_field($album_nombre);
        $album_nombre = str_replace('\\', '', $album_nombre);

    
        if ($album_nombre != NULL && $album_nombre != ''){
            
            // Creo el album

            $album_datos  = array (
                            'nombre'=>$album_nombre,	
                            'tiempo_subido'=>current_time( 'mysql' ),	
                            'tiempo_editado'=>current_time( 'mysql' ),
                            'genero'=> ik_woomusicdb_datainfo('genero'),
                    );
            
            //Chequeo si tiene year de album o interpretes
            $dato_titulo = explode(" - ", $album_nombre);
            if (isset($dato_titulo[0])){
                $interpretes = sanitize_text_field($dato_titulo[0]);
                
                //agrego los interpretes del abum
                $album_datos['interpretes'] =$interpretes;
            }
            if (isset($dato_titulo[1])){
                $year = intval($dato_titulo[1]);
                
                if ($year > 0){
                    //agrego el year del abum
                    $album_datos['year'] =$year;
                }
            }
            
            global $wpdb;
            $rowResult = $wpdb->insert($this->db_table_albums, $album_datos);   
            $album_id = $wpdb->insert_id;
            
            return $album_id;
      
        }
        
        return 0;
    }
    
    //True o false si existe o no album ID
    public function get_album_by_id($album_id){
        $album_id = absint($album_id);
        
        if ( $album_id > 0){
            
            global $wpdb;
            $queryAlbum = "SELECT * FROM ".$this->db_table_albums." WHERE id = ".$album_id;
            $albums = $wpdb->get_results($queryAlbum);
    
            if (isset($albums[0]->id)){ 
                return $albums[0];
            }
        }
        
        return false;
        
    }

    //agregar imagenes de portada de album
    public function agregar_imagenes_album($id_album, $id_imgs){
        
        $id_album = absint($id_album);
        
        if (is_array($id_imgs)){
            foreach ( $id_imgs as $id_img){
                $id_img = absint($id_img);
                if ($id_img != 0){
              
                    // Asocio la imagen a array de imagenes de album
                    $imagenes_id[] = $id_img;
                }
            }
        	
        	//Si se agregaron imagenes al array imagenes_id
        	if (isset($imagenes_id)){
        		//serializo el array
        		$imagenes_id_serializado = maybe_serialize($imagenes_id);
        		
        		global $wpdb;
        		$where = [ 'id' => $id_album ];
        			
        		$datos_imagenes  = array (
        						'id_imgs'=>$imagenes_id_serializado,
        						'tiempo_editado' =>	current_time( 'mysql' ),
        				);
        		$rowResult = $wpdb->update($this->db_table_albums,  $datos_imagenes , $where);
        		
        		return true;
        	}
        }
    	return false;
    }
    
    public function buscar_albums_listar($search_input){
        $search_input = sanitize_text_field($search_input);
        $results = '';
        
        global $wpdb;
        $queryBuscarAlbum = "SELECT * FROM ".$this->db_table_albums." WHERE nombre LIKE '%".$search_input."%' OR interpretes LIKE '%".$search_input."%' OR descripcion LIKE '%".$search_input."%' LIMIT 5";
        $albumsEncontrados = $wpdb->get_results($queryBuscarAlbum);
        
        // I assign values for comments from admin and translator
        if (isset($albumsEncontrados[0]->id)){
            foreach ( $albumsEncontrados as $album ) {
                $results .= '<li class="ik_woomusicadb_album" nombre_album="'.$album->nombre.'" album_id="'.$album->id.'">#'.$album->id.' - '.$album->nombre.' - '.$album->interpretes.'</li>';
            }
        }
        
        return $results;
    }
    
    //devolver imgs de album
    public function get_imgs($id_album){
        $id_album = absint($id_album);
		
		global $wpdb;
		$queryAlbum = "SELECT id_imgs FROM ".$this->db_table_albums." WHERE id=".$id_album;
		$album = $wpdb->get_results($queryAlbum);

		if (isset($album[0]->id_imgs)){
		    return $album[0]->id_imgs;
		} else {
		    return false;   
		}
        
    }
    
    //actualizar datos de album
    public function actualizar_datos($id_album, $dato, $valor){
        
        $id_album = absint($id_album);
        $dato_ingresado = sanitize_text_field($dato);
        $input_ingresado = sanitize_text_field($valor);
		$input_ingresado = str_replace("\\", "", $input_ingresado);
		
		if ($dato_ingresado == 'nombre'){
			$dato_album  = array (
				'nombre'=>$input_ingresado,
			);			
		} else if ($dato_ingresado == 'interpretes'){
			$dato_album  = array (
				'interpretes'=>$input_ingresado,
			);						
		} else if ($dato_ingresado == 'year'){
			$dato_album  = array (
				'year'=>absint($input_ingresado),
			);						
		} else if ($dato_ingresado == 'genero'){
			$dato_album  = array (
				'genero'=>$input_ingresado,
			);						
		} else {
			//Descripcion
			$dato_album  = array (
				'descripcion'=>$input_ingresado,
			);			
		}
		
		$dato_album['tiempo_editado'] =	current_time( 'mysql' );
		
		global $wpdb;
		$where = [ 'id' => $id_album ];

		$rowResult = $wpdb->update($this->db_table_albums, $dato_album , $where);       
		
		return true;
        
    }
    
    //agregar a favoritos
    public function agregar_favoritos($album_id, $valor){
        $album_id = absint($album_id);
        
        if ($valor < 2){
        
            $dato_album['fav'] = $valor;
    
    		global $wpdb;
    		$where = [ 'id' => $album_id ];
    
    		$rowResult = $wpdb->update($this->db_table_albums, $dato_album, $where);
		
        }
        
        return;
    }

    //Listar total de albums 
    private function get_total_albums(){
        global $wpdb;

        // Consulta SQL para contar los registros
        $query = "SELECT COUNT(*) FROM ".$this->db_table_albums;

        // Ejecutar la consulta y obtener el resultado
        $total = $wpdb->get_var($query);

        return $total;
    }
    
    //Listar albums
    public function get_albums($qty = 30, $orderby = 'id', $orderdir = 'DESC', $keyword = ''){
        
        // Veo el paginado
        $page = 1;
        if (isset($_GET["pagina"])){
            if (strval($_GET["pagina"]) == strval(intval($_GET["pagina"])) && $_GET["pagina"] > 0){
                $page = intval($_GET["pagina"]);
            }
        }
        
        $qty = absint($qty);
        $offsetList = ($page - 1) * $qty;
        $where = '';
        
        if ($orderby !== 'id'){
            if ($orderby == 'nombre'){
                $orderby = 'nombre';
            } else if ($orderby == 'interpretes'){
                $orderby = 'interpretes';
            } else if ($orderby == 'tiempo_editado'){
                $orderby = 'tiempo_editado';
            } else if ($orderby == 'year'){
                $orderby = 'year';
            } else if ($orderby == 'genero'){
                $orderby = 'genero';
            } else {
                $orderby = 'id';
            }
        }
        
        if ($orderdir !== 'DESC'){
            $orderdir = 'ASC';
        }

    
        if ($page > 0 && is_int($qty)){
    	    $offset = ' LIMIT '.$qty.' OFFSET '.$offsetList;
    	} else {
    	    $offset = '';
    	}
        
        global $wpdb;
        $tabla_albums = $this->db_table_albums;
        
        if ($keyword !== ''){
            $keyword = sanitize_text_field($keyword);
            $cancionData = new Ik_MusicaDB_Canciones();
            $tabla_canciones = $cancionData->db_table_canciones;
            
            $queryToSelect = "DISTINCT ".$tabla_albums.".id, ".$tabla_albums.".nombre,
            ".$tabla_albums.".interpretes, ".$tabla_albums.".year, ".$tabla_albums.".genero,
            ".$tabla_albums.".tiempo_subido, ".$tabla_albums.".tiempo_editado, ".$tabla_albums.".fav,
            ".$tabla_albums.".id_imgs";
        
            $tablasSelect = $tabla_albums.", ".$tabla_canciones;
            
            $querywhere = "WHERE ".$tabla_albums.".nombre LIKE '%".$keyword."%' OR 
            ".$tabla_albums.".year LIKE '%".$keyword."%' OR 
            ".$tabla_albums.".descripcion LIKE '%".$keyword."%' OR 
            ".$tabla_albums.".interpretes LIKE '%".$keyword."%'";
            
        } else {
            $queryToSelect = '*';
            $tablasSelect = $tabla_albums;
            $querywhere = '';
        }

        
        $queryAlbums = "SELECT ".$queryToSelect." FROM ".$tablasSelect." ".$querywhere." 
        ORDER BY ".$tabla_albums.".".$orderby." ".$orderdir." ".$offset;        

        $albumsEncontrados = $wpdb->get_results($queryAlbums);
        
        // I assign values for comments from admin and translator
        if (isset($albumsEncontrados[0]->id)){
            
            $queryAlbumsTodo = "SELECT DISTINCT ".$tabla_albums.".id FROM ".$tablasSelect;       
    
            $albumsTodo = $wpdb->get_results($queryAlbumsTodo);
            
            $countTotal = count($albumsTodo);
                
            $albums = new \stdClass();
            $albums->listado = $albumsEncontrados;
            $albums->total = $countTotal;
  
            return $albums;
        }
        
        return false;
    }

    //Devolver albums favoritos
    public function get_fav_albums($qty = 8, $orderby = 'nombre', $orderdir = 'DESC'){
        
        $qty = absint($qty);
        
        if ($orderby !== 'nombre'){
            if ($orderby == 'id'){
                $orderby = 'id';
            } else if ($orderby == 'interpretes'){
                $orderby = 'interpretes';
            } else if ($orderby == 'tiempo_editado'){
                $orderby = 'tiempo_editado';
            } else if ($orderby == 'year'){
                $orderby = 'year';
            } else if ($orderby == 'genero'){
                $orderby = 'genero';
            } else {
                $orderby = 'nombre';
            }
        }
        
        if ($orderdir !== 'DESC'){
            $orderdir = 'ASC';
        }

        
        global $wpdb;
        $tabla_albums = $this->db_table_albums;
        $queryAlbums = "SELECT ".$tabla_albums.".id FROM ".$tabla_albums." WHERE fav = 1 ORDER BY ".$tabla_albums.".".$orderby." ".$orderdir." LIMIT ".$qty;        

        $albumsEncontrados = $wpdb->get_results($queryAlbums);
        
        // I assign values for comments from admin and translator
        if (isset($albumsEncontrados[0]->id)){
            
            $infoAlbums = '';
            $columnCount = 0;

            //to link search for albums
            $url_search = get_option('ik_woomusicadb_url_search');

            //cambio la url search basado en el idioma
            if(function_exists('pll_default_language') && function_exists('pll_current_language')){
                $default_language = pll_default_language(); // Obtener el idioma predeterminado de Polylang
                $current_language = pll_current_language(); // Obtener el idioma actual de la página
            
                if ($default_language !== $current_language) {

                    $post_id = url_to_postid($url_search);

                    if ($post_id) {
                        // Obtener el permalink correspondiente al ID de la entrada en el idioma actual
                        $language_permalink = get_permalink(pll_get_post($post_id));
                        $url_search = $language_permalink;
                    }
                }
            }
            
            foreach($albumsEncontrados as $album){

                $album = $this->get_album_by_id($album->id);
        
                //Verifico si el album existe
                if ($album !== false){
                    if($columnCount == 0){ 
                        $infoAlbums .= '<div class="ik_music_db_fav_album_data_row">'; 
                    }
                         
                    $cancionData = new Ik_MusicaDB_Canciones();
                    $canciones = $cancionData->get_canciones_album($album->id, 'tienda');
        
                    $album_foto = ik_woomusicadb_get_imagenes_album($album->id_imgs, 'tienda');
                            
                    $infoAlbums .= '            
                        <div class="ik_music_db_fav_album_data">
                        <div class="ik_music_db_album_columna">
                            <div class="ik_woomusicadb_album_portada">
                                <a href="'.$url_search.'?searchall='.$album->nombre.'&g-recaptcha-response=0&g-recaptcha-response=0">
                                '.$album_foto.'
                                </a>
                            </div>
                            <div class="ik_woomusicadb_album_medio_detalles">
                                <div class="ik_musicadb_titulo_album">
                                    <span><b>'. __( 'Título', 'ik-musicdb' ).':</b> </span>
                                    <span class="ik_musicadb_titulo_album">'.$album->nombre.'</span>
                                </div>
                                <div class="ik_musicadb_interpretes_album">
                                    <span><b>'. __( 'Intérpretes', 'ik-musicdb' ).':</b> </span>
                                    <span class="ik_musicadb_interpretes_album">'.$album->interpretes.'</span>
                                </div>
                                <div class="ik_musicadb_year_album">
                                    <span><b>'. __( 'Año', 'ik-musicdb' ).':</b> </span>
                                    <span class="ik_musicadb_year_album">'.$album->year.'</span>                         
                                </div>
                                <div class="ik_musicadb_genero_album">
                                    <span><b>'. __( 'Género', 'ik-musicdb' ).':</b> </span>
                                    <span class="ik_musicadb_genero_album">'.$album->genero.'</span>                      
                                </div>
                            </div>
                        </div>
                        <div class="ik_music_db_album_columna ik_music_db_album_columna_canciones">
                            <h3>'. __( 'Lista de canciones', 'ik-musicdb' ).'</h3>
                            <div class="ik_music_db_album_columna_canciones_inner">
                            '.$canciones.'
                            </div>    
                        </div>
                    </div>';

                    if($columnCount != 0){ 
                        $infoAlbums .= '</div>'; 
                        $columnCount = 0;
                    } else {
                        $columnCount = $columnCount + 1; 
                    }
                }
            }

            return $infoAlbums;
        }
        
        return false;
    }


    //eliminar canciones por album_id
    public function eliminar($album_id){
        $album_id = absint($album_id);
        global $wpdb;
        $wpdb->delete( $this->db_table_albums , array( 'id' => $album_id ) );
        
        return true;
    }
}


?>