<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>