<?php
/*
Plugin Name: IK Woo Musica (Base de datos de música conectada a Woocommerce)
Description: Permite subir música a una base de datos y comercializarla por Woocommerce
Version: 2.5.3
Author: Gabriel Caroprese / Inforket.com
Author URI: https://inforket.com/
Requires at least: 5.3
Requires PHP: 7.2
*/ 

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

$wooMusicaDir = dirname( __FILE__ );
$wooMusicaPublicDir = plugin_dir_url(__FILE__ );
define( 'IK_WOOMUSICADB_PLUGIN_DIR', $wooMusicaDir );
define( 'IK_WOOMUSICADB_PLUGIN_PUBLIC', $wooMusicaPublicDir );
define( 'IK_WOOMUSICADB_ALBUM_DEFECTO', $wooMusicaPublicDir.'img/albumdefecto.jpg' );
define( 'IK_WOOMUSICADB_DEMO_MINUTOS_DEFECTO', 30 );
define( 'IK_WOOMUSICADB_PRECIO_CANCIONES_DEFECTO', 3 );
define( 'IK_WOOMUSICADB_GENERO_DEFECTO', 'Tango' );
define( 'IK_WOOMUSICADB_ARCHIVOS_TEMP', 'musica_db' );
define( 'IK_WOOMUSICADB_ARCHIVOS_TEMP_PLAY', 'music_audio_temp' );


//I add plugin functions
require_once($wooMusicaDir . '/include/init.php');
require_once($wooMusicaDir . '/include/functions.php');
require_once($wooMusicaDir . '/include/ajax_functions.php');
require_once($wooMusicaDir . '/include/classes/canciones.class.php');
require_once($wooMusicaDir . '/include/classes/album.class.php');
require_once($wooMusicaDir . '/include/shortcodes/buscador.php');
require_once($wooMusicaDir . '/include/shortcodes/albums_destacados.php');

register_activation_hook( __FILE__, 'ik_woomusicadb_config_db_files' );

//Load language files
function ik_woomusicadb_textdomain_init() {
    load_plugin_textdomain( 'ik-musicdb', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'plugins_loaded', 'ik_woomusicadb_textdomain_init' );

?>